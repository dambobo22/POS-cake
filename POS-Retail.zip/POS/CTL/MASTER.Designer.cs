﻿namespace POS.CTL
{
    partial class MASTER
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbMaster = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lst = new System.Windows.Forms.ListView();
            this.control = new System.Windows.Forms.Panel();
            this.lblUOM = new System.Windows.Forms.Label();
            this.cbUOM = new System.Windows.Forms.ComboBox();
            this.btnCheck = new System.Windows.Forms.PictureBox();
            this.btnDelete = new System.Windows.Forms.PictureBox();
            this.btnCancel2 = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.txtColumn = new System.Windows.Forms.TextBox();
            this.lblColumn = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.line = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.btnCancel = new System.Windows.Forms.PictureBox();
            this.btnAdd = new System.Windows.Forms.PictureBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip2 = new System.Windows.Forms.ToolTip(this.components);
            this.toolTip3 = new System.Windows.Forms.ToolTip(this.components);
            this.control.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCheck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).BeginInit();
            this.SuspendLayout();
            // 
            // cbMaster
            // 
            this.cbMaster.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMaster.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbMaster.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.cbMaster.FormattingEnabled = true;
            this.cbMaster.Location = new System.Drawing.Point(14, 129);
            this.cbMaster.Name = "cbMaster";
            this.cbMaster.Size = new System.Drawing.Size(540, 58);
            this.cbMaster.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.label1.Location = new System.Drawing.Point(797, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 54);
            this.label1.TabIndex = 5;
            this.label1.Text = "MASTER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.label2.Location = new System.Drawing.Point(14, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(216, 50);
            this.label2.TabIndex = 6;
            this.label2.Text = "PILIH TABEL";
            // 
            // lst
            // 
            this.lst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lst.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.lst.FullRowSelect = true;
            this.lst.GridLines = true;
            this.lst.Location = new System.Drawing.Point(14, 193);
            this.lst.MultiSelect = false;
            this.lst.Name = "lst";
            this.lst.Size = new System.Drawing.Size(1038, 270);
            this.lst.TabIndex = 7;
            this.lst.UseCompatibleStateImageBehavior = false;
            this.lst.View = System.Windows.Forms.View.Details;
            // 
            // control
            // 
            this.control.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.control.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.control.Controls.Add(this.lblUOM);
            this.control.Controls.Add(this.cbUOM);
            this.control.Controls.Add(this.btnCheck);
            this.control.Controls.Add(this.btnDelete);
            this.control.Controls.Add(this.btnCancel2);
            this.control.Controls.Add(this.btnSave);
            this.control.Controls.Add(this.txtColumn);
            this.control.Controls.Add(this.lblColumn);
            this.control.Controls.Add(this.shapeContainer1);
            this.control.Location = new System.Drawing.Point(0, 277);
            this.control.Name = "control";
            this.control.Size = new System.Drawing.Size(1073, 200);
            this.control.TabIndex = 9;
            this.control.Visible = false;
            // 
            // lblUOM
            // 
            this.lblUOM.AutoSize = true;
            this.lblUOM.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.lblUOM.ForeColor = System.Drawing.Color.White;
            this.lblUOM.Location = new System.Drawing.Point(693, 6);
            this.lblUOM.Name = "lblUOM";
            this.lblUOM.Size = new System.Drawing.Size(108, 50);
            this.lblUOM.TabIndex = 17;
            this.lblUOM.Text = "UOM";
            this.lblUOM.Visible = false;
            // 
            // cbUOM
            // 
            this.cbUOM.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbUOM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbUOM.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.cbUOM.FormattingEnabled = true;
            this.cbUOM.Location = new System.Drawing.Point(690, 59);
            this.cbUOM.Name = "cbUOM";
            this.cbUOM.Size = new System.Drawing.Size(332, 58);
            this.cbUOM.TabIndex = 16;
            this.cbUOM.Visible = false;
            // 
            // btnCheck
            // 
            this.btnCheck.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCheck.Location = new System.Drawing.Point(14, 66);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(59, 58);
            this.btnCheck.TabIndex = 15;
            this.btnCheck.TabStop = false;
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.Location = new System.Drawing.Point(144, 128);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(59, 58);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.TabStop = false;
            this.toolTip2.SetToolTip(this.btnDelete, "DELETE");
            // 
            // btnCancel2
            // 
            this.btnCancel2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCancel2.Location = new System.Drawing.Point(79, 128);
            this.btnCancel2.Name = "btnCancel2";
            this.btnCancel2.Size = new System.Drawing.Size(59, 58);
            this.btnCancel2.TabIndex = 12;
            this.btnCancel2.TabStop = false;
            this.toolTip1.SetToolTip(this.btnCancel2, "CANCEL");
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.Location = new System.Drawing.Point(14, 128);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(59, 58);
            this.btnSave.TabIndex = 11;
            this.btnSave.TabStop = false;
            this.toolTip3.SetToolTip(this.btnSave, "OK");
            // 
            // txtColumn
            // 
            this.txtColumn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.txtColumn.BackColor = System.Drawing.Color.SkyBlue;
            this.txtColumn.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtColumn.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtColumn.Font = new System.Drawing.Font("Segoe UI", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtColumn.ForeColor = System.Drawing.Color.White;
            this.txtColumn.Location = new System.Drawing.Point(79, 62);
            this.txtColumn.Name = "txtColumn";
            this.txtColumn.Size = new System.Drawing.Size(605, 50);
            this.txtColumn.TabIndex = 8;
            // 
            // lblColumn
            // 
            this.lblColumn.AutoSize = true;
            this.lblColumn.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.lblColumn.ForeColor = System.Drawing.Color.White;
            this.lblColumn.Location = new System.Drawing.Point(5, 9);
            this.lblColumn.Name = "lblColumn";
            this.lblColumn.Size = new System.Drawing.Size(0, 50);
            this.lblColumn.TabIndex = 7;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.line});
            this.shapeContainer1.Size = new System.Drawing.Size(1073, 200);
            this.shapeContainer1.TabIndex = 13;
            this.shapeContainer1.TabStop = false;
            // 
            // line
            // 
            this.line.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.line.BorderColor = System.Drawing.Color.White;
            this.line.Name = "line";
            this.line.X1 = 80;
            this.line.X2 = 683;
            this.line.Y1 = 115;
            this.line.Y2 = 115;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(625, 129);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(59, 58);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.TabStop = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(560, 129);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(59, 58);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.TabStop = false;
            // 
            // MASTER
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.control);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lst);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbMaster);
            this.Name = "MASTER";
            this.Size = new System.Drawing.Size(1073, 480);
            this.control.ResumeLayout(false);
            this.control.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCheck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbMaster;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListView lst;
        private System.Windows.Forms.PictureBox btnAdd;
        private System.Windows.Forms.Panel control;
        private System.Windows.Forms.PictureBox btnCancel;
        private System.Windows.Forms.Label lblColumn;
        private System.Windows.Forms.PictureBox btnCancel2;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.TextBox txtColumn;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape line;
        private System.Windows.Forms.PictureBox btnDelete;
        private System.Windows.Forms.PictureBox btnCheck;
        private System.Windows.Forms.ComboBox cbUOM;
        private System.Windows.Forms.Label lblUOM;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ToolTip toolTip2;
        private System.Windows.Forms.ToolTip toolTip3;
    }
}
