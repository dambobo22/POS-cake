﻿namespace POS.CTL
{
    partial class PASSWORD
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.control = new System.Windows.Forms.Panel();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnCancel2 = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.txtPengguna = new System.Windows.Forms.TextBox();
            this.lblColumn = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.control.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.label1.Location = new System.Drawing.Point(503, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(357, 54);
            this.label1.TabIndex = 5;
            this.label1.Text = "PENGGUNA DETAIL";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // control
            // 
            this.control.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.control.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.control.Controls.Add(this.txtemail);
            this.control.Controls.Add(this.label5);
            this.control.Controls.Add(this.txtfirstname);
            this.control.Controls.Add(this.label4);
            this.control.Controls.Add(this.txtPass);
            this.control.Controls.Add(this.label3);
            this.control.Controls.Add(this.btnCancel2);
            this.control.Controls.Add(this.btnSave);
            this.control.Controls.Add(this.txtPengguna);
            this.control.Controls.Add(this.lblColumn);
            this.control.Controls.Add(this.shapeContainer1);
            this.control.Location = new System.Drawing.Point(0, 120);
            this.control.Name = "control";
            this.control.Size = new System.Drawing.Size(860, 407);
            this.control.TabIndex = 9;
            this.control.Visible = false;
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.SkyBlue;
            this.txtemail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtemail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtemail.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.ForeColor = System.Drawing.Color.White;
            this.txtemail.Location = new System.Drawing.Point(20, 284);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(602, 39);
            this.txtemail.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(21, 249);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 40);
            this.label5.TabIndex = 20;
            this.label5.Text = "EMAIL";
            // 
            // txtfirstname
            // 
            this.txtfirstname.BackColor = System.Drawing.Color.SkyBlue;
            this.txtfirstname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtfirstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtfirstname.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirstname.ForeColor = System.Drawing.Color.White;
            this.txtfirstname.Location = new System.Drawing.Point(20, 201);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(602, 39);
            this.txtfirstname.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(19, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 40);
            this.label4.TabIndex = 18;
            this.label4.Text = "NAMA DEPAN";
            // 
            // txtPass
            // 
            this.txtPass.BackColor = System.Drawing.Color.SkyBlue;
            this.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPass.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPass.ForeColor = System.Drawing.Color.White;
            this.txtPass.Location = new System.Drawing.Point(19, 120);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(602, 39);
            this.txtPass.TabIndex = 17;
            this.txtPass.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(19, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 40);
            this.label3.TabIndex = 16;
            this.label3.Text = "KATA KUNCI";
            // 
            // btnCancel2
            // 
            this.btnCancel2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCancel2.Location = new System.Drawing.Point(72, 338);
            this.btnCancel2.Name = "btnCancel2";
            this.btnCancel2.Size = new System.Drawing.Size(59, 58);
            this.btnCancel2.TabIndex = 12;
            this.btnCancel2.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.Location = new System.Drawing.Point(7, 338);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(59, 58);
            this.btnSave.TabIndex = 11;
            this.btnSave.TabStop = false;
            // 
            // txtPengguna
            // 
            this.txtPengguna.BackColor = System.Drawing.Color.SkyBlue;
            this.txtPengguna.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPengguna.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPengguna.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPengguna.ForeColor = System.Drawing.Color.White;
            this.txtPengguna.Location = new System.Drawing.Point(19, 38);
            this.txtPengguna.Name = "txtPengguna";
            this.txtPengguna.Size = new System.Drawing.Size(602, 39);
            this.txtPengguna.TabIndex = 8;
            // 
            // lblColumn
            // 
            this.lblColumn.AutoSize = true;
            this.lblColumn.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColumn.ForeColor = System.Drawing.Color.White;
            this.lblColumn.Location = new System.Drawing.Point(19, 0);
            this.lblColumn.Name = "lblColumn";
            this.lblColumn.Size = new System.Drawing.Size(171, 40);
            this.lblColumn.TabIndex = 7;
            this.lblColumn.Text = "PENGGUNA";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.line});
            this.shapeContainer1.Size = new System.Drawing.Size(860, 407);
            this.shapeContainer1.TabIndex = 13;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.BorderColor = System.Drawing.Color.White;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 19;
            this.lineShape3.X2 = 617;
            this.lineShape3.Y1 = 242;
            this.lineShape3.Y2 = 242;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.Color.White;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 19;
            this.lineShape2.X2 = 617;
            this.lineShape2.Y1 = 161;
            this.lineShape2.Y2 = 161;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.White;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 19;
            this.lineShape1.X2 = 617;
            this.lineShape1.Y1 = 79;
            this.lineShape1.Y2 = 79;
            // 
            // line
            // 
            this.line.BorderColor = System.Drawing.Color.White;
            this.line.Name = "line";
            this.line.X1 = 21;
            this.line.X2 = 619;
            this.line.Y1 = 325;
            this.line.Y2 = 325;
            // 
            // PASSWORD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.control);
            this.Controls.Add(this.label1);
            this.Name = "PASSWORD";
            this.Size = new System.Drawing.Size(863, 594);
            this.control.ResumeLayout(false);
            this.control.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel control;
        private System.Windows.Forms.Label lblColumn;
        private System.Windows.Forms.PictureBox btnCancel2;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.TextBox txtPengguna;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape line;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Label label3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
    }
}
