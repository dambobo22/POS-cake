﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS.CTL
{
    public partial class KASIR : UserControl
    {
        kp _kp;
        main m;
        bool isupdate = false;
        string oldName = "";
        int harga = 0;
        int available = 0;
        public KASIR(kp _k, main _main)
        {
            InitializeComponent();
            _kp = _k;
            m = _main;
            btnAdd.Image = _kp.ImgPay;
            btnCancel.Image = _kp.ImgCancel;
            btnADDITEM.Image = _kp.ImgSave;
            btnCANCELITEM.Image = _kp.ImgCancel;
            btnSave.Image = _kp.ImgSave;
            btnCancel2.Image = _kp.ImgCancel;
            btntunda.Image = _kp.ImgLogout;
            LoadHold();
            btnAdd.Click += btnAdd_Click;
            btnCancel.Click += btnCancel_Click;
            btnCancel2.Click += btnCancel2_Click;
            btnSave.Click += btnSave_Click;
            btntunda.Click += btntunda_Click;
            menu.DoubleClick += menu_DoubleClick;
            lst.DoubleClick += lst_DoubleClick;
            _kp.SetAutoComplete(txtCari, "select REPLACE(stockName,' ','_') + ' ' + tasteName + ' ' + categoryName + ' ' + Name + ' (' + CONVERT(VARCHAR(100),qty) + ')' from tStock A " +
                                         "inner join tTaste B ON A.tasteId =  B.tasteId " +
                                         "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                                         "inner join (select uomId as ID,uomName as NAME from tUOM UNION select sizeId as ID,sizeName as NAME from tSize) D ON A.uomId = D.ID " +
                                         "where qty > 0");
            txtCari.KeyDown += txtCari_KeyDown;
            txtdibayar.KeyDown += txtdibayar_KeyDown;
            txtdibayar.KeyPress += _k.DecimalOnly;
            txttotalitem.KeyPress += _k.DecimalOnly;
            txttotalitem.TextChanged += txttotalitem_TextChanged;
            txtdibayar.TextChanged += txtdibayar_TextChanged;
            cbtunda.SelectedIndexChanged += cbtunda_SelectedIndexChanged;
            btnADDITEM.Click += btnADDITEM_Click;
            btnCANCELITEM.Click += btnCANCELITEM_Click;
        }
        void btnCancel2_Click(object sender, EventArgs e)
        {
            control.Location = new Point(0, -1200);
            control.Size = new Size(this.Width, control.Height);
            txtbiaya.Text = "";
            txtdibayar.Text = "";
            txtkembalian.Text = "";
            btnSave.Visible = false;
            ITEMS.Location = new Point(0, -1200);
            ITEMS.Size = new Size(this.Width, ITEMS.Height);
            txtITEM.Text = "";
            txttotalitem.Text = "";
            txtTOTALHARGA.Text = "";
            lblavailable.Text = "JUMLAH";
            enable();
            LoadHold();
        }
        void btnCANCELITEM_Click(object sender, EventArgs e)
        {
            ITEMS.Location = new Point(0, -1200);
            ITEMS.Size = new Size(this.Width, ITEMS.Height);
            txtITEM.Text = "";
            txttotalitem.Text = "";
            txtTOTALHARGA.Text = "";
            lblavailable.Text = "JUMLAH";
            enable();
            LoadHold();
        }
        void txttotalitem_TextChanged(object sender, EventArgs e)
        {
            if (txttotalitem.Text != "")
            {
                if (_kp.ValidateInput(kp.InputType.NumericOnly, txttotalitem.Text) != txttotalitem.Text)
                {
                    m.MessageInfo(main.MessageType.Alert, "TOTAL ITEM HANYA BOLEH NUMERIC", 100);
                    txttotalitem.Focus();
                }
                else
                {
                    int qty = 0;
                    qty = Convert.ToInt32(txttotalitem.Text);
                    if (qty <= available)
                    {

                        txtTOTALHARGA.Text = (qty * harga).ToString();

                    }
                    else
                    {
                        txttotalitem.Text = "0";
                    }
                }
            }
        }
        void btnADDITEM_Click(object sender, EventArgs e)
        {
            if (txttotalitem.Text != "0" && txttotalitem.Text != "")
            {

                bool exist = false;
                ListViewItem _L = null;
                int totalharga = 0;
                int totalqty = 0;
                foreach (ListViewItem l in lst.Items)
                {
                    if (l.Text == txtITEM.Text)
                    {
                        exist = true;
                        _L = l;
                        break;
                    }
                }
                if (exist)
                {
                    int qty = Convert.ToInt32(_L.SubItems[1].Text);
                    int harga = Convert.ToInt32(_L.SubItems[2].Text);
                    harga = harga / qty;
                    int newqty = Convert.ToInt32(txttotalitem.Text);
                    qty = qty + newqty;
                    for (int i = 0; i < lst.Items.Count; i++)
                    {
                        if (lst.Items[i].Text != "")
                        {
                            DataTable cekstok = _kp.S(String.Format("select unitPrice from tStock where stockName = '{0}' and qty >= {1}", lst.Items[i].Text, qty));
                            if (cekstok.Rows.Count > 0)
                            {
                               
                                _L.SubItems[1].Text = qty.ToString();
                                _L.SubItems[2].Text = (harga * qty).ToString();
                                available = available - newqty;
                            }
                            else
                            {
                                m.MessageInfo(main.MessageType.Alert, String.Format("STOK {0} TIDAK CUKUP", lst.Items[i].Text), 200);
                                break;
                            }
                        }
                    }

                }
                else
                {
                    int newqty = Convert.ToInt32(txttotalitem.Text);
                    available = available - newqty;                 
                    lst.Items.Add(new ListViewItem(new string[] { txtITEM.Text, txttotalitem.Text, txtTOTALHARGA.Text }));
                }

                foreach (ListViewItem l in lst.Items)
                {
                    totalharga += Convert.ToInt32(l.SubItems[2].Text);
                    totalqty += Convert.ToInt32(l.SubItems[1].Text);
                }
                lbltotal.Text = String.Format("Total QTY :{0} Pcs Total Harga: {1}", totalqty, totalharga);
                btnCANCELITEM_Click(sender, null);
            }
        }
        void btntunda_Click(object sender, EventArgs e)
        {
            string insertquery = "";
            string item = "";
            string itemmenu = "";
            DataTable cekdata = new DataTable();
            int itemno = 0;
            string NEWID = _kp.NEWID();
            foreach (ListViewItem L in lst.Items)
            {
                item += String.Format("select stockName from tStock where stockName = '{0}' and qty >= {1}{2}", L.Text, L.SubItems[1].Text, Environment.NewLine);
                itemmenu += String.Format("insert into tStockOutDetail values(NEWID(),'{0}','{1}',{2},GETDATE()){3}", NEWID, L.Text, L.SubItems[1].Text, Environment.NewLine);
                itemno++;
                if (itemno < lst.Items.Count)
                {
                    item += String.Format("UNION{0}", Environment.NewLine);
                }
            }
            cekdata = _kp.S(item);
            if (cekdata.Rows.Count == lst.Items.Count)
            {

                insertquery = String.Format("insert into tStockOut values('{0}',0,0,0,GETDATE(),NULL)", NEWID);
                insertquery = itemmenu + insertquery;
                if (_kp.CUD(insertquery, m.username))
                {
                    m.MessageInfo(main.MessageType.Success, "TUNDA TRANSAKSI BERHASIL", 100);
                    Clear(sender);
                }
                else
                {
                    m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                }
            }
            else
            {
                m.MessageInfo(main.MessageType.Alert, "STOK TIDAK CUKUP, PERBAIKI STOK ATAU ITEM YANG DIBELI", 100);
            }

        }
        void cbtunda_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbtunda.Text != "")
            {
                string[] _cbtunda = cbtunda.Text.Split('.');
                if (_cbtunda.Length > 1)
                {
                    DataTable GetHold = _kp.S(String.Format("select A.stockOutId,B.stockName,B.qty as QTY,C.unitPrice from tStockOut A " +
                                                            "inner join tStockOutDetail B ON A.stockOutId  =B.stockOutId " +
                                                            "inner join tStock C ON B.stockName = C.stockName " +
                                                            "where CONVERT(VARCHAR(100),A.createdDate,120) = '{0}'", _cbtunda[1]));
                    if (GetHold.Rows.Count > 0)
                    {
                        string deletequery = String.Format("delete from tStockOut where stockOutId = '{0}' " +
                                                           "delete from tStockOutDetail where stockOutId = '{0}'", GetHold.Rows[0].ItemArray[0].ToString());
                        if (_kp.CUD(deletequery, m.username))
                        {
                            lst.Items.Clear();
                            foreach (DataRow r in GetHold.Rows)
                            {
                                object[] o = r.ItemArray;
                                lst.Items.Add(new ListViewItem(new string[] { o[1].ToString(), o[2].ToString(), o[3].ToString() }));
                            }
                            int totalharga = 0;
                            int totalqty = 0;
                            foreach (ListViewItem l in lst.Items)
                            {
                                totalharga += Convert.ToInt32(l.SubItems[2].Text);
                                totalqty += Convert.ToInt32(l.SubItems[1].Text);
                            }
                            lbltotal.Text = String.Format("Total QTY :{0} Pcs Total Harga: {1}", totalqty, totalharga);
                            LoadHold();
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM", 100);
                            txtCari.Focus();
                        }
                    }
                }
            }
        }
        void lst_DoubleClick(object sender, EventArgs e)
        {
            if (lst.SelectedItems != null)
            {
                bool exist = false;
                ListViewItem _L = null;
                string StockName = lst.SelectedItems[0].Text;
                foreach (ListViewItem l in lst.Items)
                {
                    if (l.Text == StockName)
                    {
                        exist = true;
                        _L = l;
                        break;
                    }
                }
                if (exist)
                {

                    //int qty = Convert.ToInt32(_L.SubItems[1].Text);
                    //if (qty > 1)
                    //{
                    //    int harga = Convert.ToInt32(_L.SubItems[2].Text);
                    //    int originalharga = harga / qty;

                    //    qty--;
                    //    _L.SubItems[1].Text = qty.ToString();
                    //    _L.SubItems[2].Text = (originalharga * qty).ToString();
                    //}
                    //else
                    //{
                    if (MessageBox.Show("Apakah Anda yakin menghapus record ini?", "Informasi", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        lst.Items.Remove(_L);
                    //}

                }

                int totalharga = 0;
                int totalqty = 0;
                foreach (ListViewItem l in lst.Items)
                {
                    totalharga += Convert.ToInt32(l.SubItems[2].Text);
                    totalqty += Convert.ToInt32(l.SubItems[1].Text);
                }
                lbltotal.Text = String.Format("Total QTY :{0} Pcs Total Harga: {1}", totalqty, totalharga);

            }
        }
        void txtdibayar_TextChanged(object sender, EventArgs e)
        {
            if (txtdibayar.Text != "")
            {
                if (_kp.ValidateInput(kp.InputType.NumericOnly, txtdibayar.Text) != txtdibayar.Text)
                {
                    m.MessageInfo(main.MessageType.Alert, "UANG DIBAYAR HANYA BOLEH NUMERIC", 100);
                    txtdibayar.Focus();
                }
                else
                {
                    decimal cashback = 0;
                    decimal cash = 0;
                    decimal cashpay = 0;
                    cash = Decimal.Parse(txtbiaya.Text);
                    cashpay = Decimal.Parse(txtdibayar.Text);
                    if (cashpay >= cash)
                    {
                        cashback = cashpay - cash;
                        txtkembalian.Text = String.Format("{0:C}",cashback).Replace("$","");
                        btnSave.Visible = true;
                    }
                    else
                    {
                        txtkembalian.Text = "0";
                        btnSave.Visible = false;
                    }
                }
            }
        }
        void txtdibayar_KeyDown(object sender, KeyEventArgs e)
        {
            if (txtdibayar.Text != "" && e.KeyValue == 13)
            {
                if (_kp.ValidateInput(kp.InputType.NumericOnly, txtdibayar.Text) != txtdibayar.Text)
                {
                    m.MessageInfo(main.MessageType.Alert, "UANG DIBAYAR HANYA BOLEH NUMERIC", 100);
                    txtdibayar.Focus();
                }
                else
                {
                    int cashback = 0;
                    int cash = 0;
                    int cashpay = 0;
                    cash = Convert.ToInt32(txtbiaya.Text);
                    cashpay = Convert.ToInt32(txtdibayar.Text);
                    if (cashpay >= cash)
                    {
                        cashback = cashpay - cash;
                        txtkembalian.Text = String.Format("{0:C}", cashback).Replace("$", "");
                        btnSave.Visible = true;
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "UANG DIBAYAR KURANG", 100);
                        btnSave.Visible = false;
                        txtdibayar.Focus();
                    }
                }
            }
        }
        void txtCari_KeyDown(object sender, KeyEventArgs e)
        {
            if (txtCari.Text != "" && e.KeyValue == 13)
            {
                string[] key = txtCari.Text.Split(' ');
                if (key.Length > 0)
                {
                    DataTable items = _kp.S(String.Format("select stockName,qty,unitPrice from tstock where (stockName = '{0}' OR stockName = '{1}') and qty > 0", key[0].Replace("_", " "), key[0]));
                    if (items.Rows.Count > 0)
                    {
                        disable();
                        ITEMS.Location = new Point(0, 120);
                        ITEMS.Size = new Size(this.Width, ITEMS.Height);
                        ITEMS.Visible = true;
                        ITEMS.Location = new Point(0, (this.Height / 2) - (ITEMS.Height / 2) + 60);                       
                        object[] o = items.Rows[0].ItemArray;
                        harga = Convert.ToInt32(o[2]);
                        available = Convert.ToInt32(o[1]);
                        lblavailable.Text = String.Format("JUMLAH ({0})", available);
                        txtITEM.Text = o[0].ToString();
                        txttotalitem.Text = "1";
                        txtTOTALHARGA.Text = o[2].ToString();
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "ITEM TIDAK ADA", 100);
                        return;
                    }

                }
            }
        }
       
        void menu_DoubleClick(object sender, EventArgs e)
        {
            if (menu.SelectedItems != null)
            {
                disable();
                ITEMS.Location = new Point(0, 120);
                ITEMS.Size = new Size(this.Width, ITEMS.Height);
                ITEMS.Visible = true;
                ITEMS.Location = new Point(0, (this.Height / 2) - (ITEMS.Height / 2) + 60);
                string[] key = menu.SelectedItems[0].Text.Split(' ');
                if (key.Length > 0)
                {
                    DataTable items = _kp.S(String.Format("select stockName,qty,unitPrice from tstock where (stockName = '{0}' OR stockName = '{1}') and qty > 0", key[0].Replace("_", " "), key[0]));
                    if (items.Rows.Count > 0)
                    {
                        object[] o = items.Rows[0].ItemArray;
                        harga = Convert.ToInt32(o[2]);
                        available = Convert.ToInt32(o[1]);
                        lblavailable.Text = String.Format("JUMLAH ({0})", available);
                        txtITEM.Text = o[0].ToString();
                        txttotalitem.Text = "1";
                        txtTOTALHARGA.Text = o[2].ToString();
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "ITEM TIDAK ADA", 100);
                        return;
                    }
                }
                else
                {
                    m.MessageInfo(main.MessageType.Alert, "ITEM TIDAK ADA", 100);
                    return;
                }

            }
        }
        void btnSave_Click(object sender, EventArgs e)
        {
            if (txtdibayar.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "UANG DIBAYAR TIDAK BOLEH KOSONG", 100);
                txtdibayar.Focus();
            }
            else if (_kp.ValidateInput(kp.InputType.NumericOnly, txtdibayar.Text) != txtdibayar.Text)
            {
                m.MessageInfo(main.MessageType.Alert, "UANG DIBAYAR HANYA BOLEH NUMERIC", 100);
                txtdibayar.Focus();
            }
            else
            {
                string insertquery = "";
                string item = "";
                string itemmenu = "";
                DataTable cekdata = new DataTable();
                int itemno = 0;
                string NEWID = _kp.NEWID();
                string query = "";
                foreach (ListViewItem L in lst.Items)
                {
                    DataTable stock = _kp.S(String.Format("select stockId from tStock where stockName = '{0}'", L.Text));
                    item += String.Format("select stockName from tStock where stockName = '{0}' and qty >= {1}{2}", L.Text, L.SubItems[1].Text, Environment.NewLine);
                    itemmenu += String.Format("insert into tStockOutDetail values(NEWID(),'{0}','{1}',{2},GETDATE()){3}",NEWID, stock.Rows[0].ItemArray[0].ToString(), L.SubItems[1].Text, Environment.NewLine);
                    itemmenu += String.Format(" update tStock set qty = qty - {1} where stockName = '{0}'{2}", L.Text, L.SubItems[1].Text, Environment.NewLine);
                    itemno++;
                    query += String.Format("select '{0}' as NO,stockName +',' + NAME as NAMA_BARANG,'{2}' as QTY,'{3}' as HARGA from tStock A inner join (select uomId as ID,uomName as NAME from tUOM UNION select sizeId as ID,sizeName as NAME from tSize) B ON A.uomId = B.ID where stockName = '{1}' {4}", itemno, L.Text, L.SubItems[1].Text, L.SubItems[2].Text, Environment.NewLine);
                    if (itemno < lst.Items.Count)
                    {
                        query += String.Format("UNION{0}", Environment.NewLine);
                        item += String.Format("UNION{0}", Environment.NewLine);
                    }
                }
                cekdata = _kp.S(item);
                if (cekdata.Rows.Count == lst.Items.Count)
                {

                    insertquery = String.Format("insert into tStockOut values('{0}',1,{1},{2},GETDATE(),NULL)", NEWID, Decimal.Parse(txtdibayar.Text), Decimal.Parse(txtkembalian.Text)) ;
                    insertquery = insertquery + Environment.NewLine + itemmenu;
                    if (_kp.CUD(insertquery, m.username))
                    {
                        _kp.Lap(query, kp.laporan.receipt, new string[] { NEWID.Substring(24, 12), txtdibayar.Text,txtbiaya.Text,txtkembalian.Text });
                        m.MessageInfo(main.MessageType.Success, "TRANSAKSI BERHASIL", 100);
                        Clear(sender);
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    }
                }
                else
                {
                    m.MessageInfo(main.MessageType.Alert, "STOK TIDAK CUKUP, PERBAIKI STOK ATAU ITEM YANG DIBELI", 100);
                }
            }
        }
        void btnCancel_Click(object sender, EventArgs e)
        {
            Clear(sender);
        }
        void Clear(object sender)
        {
            control.Location = new Point(0, -1200);
            control.Size = new Size(this.Width, control.Height);
            txtbiaya.Text = "";
            txtdibayar.Text = "";
            txtkembalian.Text = "";
            lst.Items.Clear();
            oldName = "";
            txtbiaya.Text = "";
            harga = 0;
            available = 0;
            txtTOTALHARGA.Text = "";
            txttotalitem.Text = "";
            txtITEM.Text = "";
            btnSave.Visible = false;
            lbltotal.Text = "";
            lblavailable.Text = "JUMLAH";
            enable();
            LoadHold();
            _kp.SetAutoComplete(txtCari, "select REPLACE(stockName,' ','_') + ' ' + tasteName + ' ' + categoryName + ' ' + Name + ' (' + CONVERT(VARCHAR(100),qty) + ')' from tStock A " +
                                         "inner join tTaste B ON A.tasteId =  B.tasteId " +
                                         "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                                         "inner join (select uomId as ID,uomName as NAME from tUOM UNION select sizeId as ID,sizeName as NAME from tSize) D ON A.uomId = D.ID " +
                                         "where qty > 0");
        }
        void btnAdd_Click(object sender, EventArgs e)
        {
            if (lst.Items.Count > 0)
            {
                int totalharga = 0;
                foreach (ListViewItem l in lst.Items)
                {
                    totalharga += Convert.ToInt32(l.SubItems[2].Text);
                }              
                txtbiaya.Text = String.Format("{0:C}", totalharga).Replace("$", "");
                control.Location = new Point(0, 120);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2) + 60);
                disable();
                txtdibayar.Focus();
            }
            else
            {
                m.MessageInfo(main.MessageType.Alert, "SILAHKAN PILIH MENU.", 200);
                txtCari.Focus();
            }
        }
        void LoadHold()
        {
            _kp.combo(String.Format("select CONVERT(VARCHAR(100),(ROW_NUMBER() OVER(ORDER BY A.CODE ASC))) + '.'+ A.CODE as CODE from (select distinct CONVERT(VARCHAR(100),A.createdDate,120) as CODE from tStockOut A " +
                                    "inner join tStockOutDetail B ON A.stockOutId  =B.stockOutId " +
                                    "where isCompleted = 0) A"), cbtunda);
            _kp.listImage("select REPLACE(stockName,' ','_') + ' ' + tasteName + ' ' + categoryName + ' ' + Name + ' (' + CONVERT(VARCHAR(100),qty) + ')', image from tStock A " +
                                        "inner join tTaste B ON A.tasteId =  B.tasteId " +
                                        "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                                        "inner join (select uomId as ID,uomName as NAME from tUOM UNION select sizeId as ID,sizeName as NAME from tSize) D ON A.uomId = D.ID " +
                                        "where qty > 0", menu, 200);
        }
        void disable()
        {
            lst.Enabled = false;
            menu.Enabled = false;
            txtCari.Enabled = false;
            cbtunda.Enabled = false;
        }
        void enable()
        {
            lst.Enabled = true;
            menu.Enabled = true;
            txtCari.Enabled = true;
            cbtunda.Enabled = true;
        }


    }
}
