﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS.CTL
{
    public partial class PASSWORD : UserControl
    {
        kp _kp;
        main m;
        bool isupdate = false;       
        string oldName = "";
        string username = "";
        public PASSWORD(kp _k, main _main)
        {
            InitializeComponent();            
            _kp = _k;            
            m = _main;
            btnSave.Image = _kp.ImgSave;
            btnCancel2.Image = _kp.ImgCancel;
            btnSave.Click += btnSave_Click;
            username = _main.username;            
            if (username != "")
            {
                DataTable pass = _kp.S(String.Format("select * from tUser where userName = '{0}'", username));
                if (pass.Rows.Count > 0)
                {
                    object[] o = pass.Rows[0].ItemArray;
                    txtPengguna.Text = username;
                    txtPengguna.Enabled = false;
                    txtPass.Text = o[3].ToString();
                    txtfirstname.Text = o[2].ToString();
                    txtemail.Text = o[1].ToString();                    
                }
               
                control.Location = new Point(0, 120);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2)); 
            }
        }        
        
        void btnSave_Click(object sender, EventArgs e)
        {
            if(txtPengguna.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "NAMA PENGGUNA TIDAK BOLEH KOSONG", 100);
                txtPengguna.Focus();
            }
            else if (txtPass.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "PASSWORD TIDAK BOLEH KOSONG", 100);
                txtPass.Focus();
            }
            else if (txtfirstname.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "NAMA DEPAN TIDAK BOLEH KOSONG", 100);
                txtfirstname.Focus();
            }
            else if (txtemail.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "EMAIL TIDAK BOLEH KOSONG", 100);
                txtemail.Focus();
            }
            else if (_kp.ValidateInput(kp.InputType.Email,txtemail.Text) != txtemail.Text)
            {
                m.MessageInfo(main.MessageType.Alert, "EMAIL FORMAT TIDAK VALID", 100);
                txtemail.Focus();
            }            
            else
            {
                string updatequery = "";                
                    updatequery = String.Format("update tUser set email = '{0}',FirstName = '{1}',passWord = '{2}',modifiedDate = GETDATE() where userName = '{3}'", txtemail.Text,txtfirstname.Text, txtPass.Text, txtPengguna.Text);
                    if (_kp.CUD(updatequery, m.username))
                    {
                        m.MessageInfo(main.MessageType.Success, String.Format("PENGGUNA {0} BERHASIL DIRUBAH", txtPengguna.Text), 100);
                        
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    }
            }
        }
    }
}
