﻿namespace POS.CTL
{
    partial class KASIR
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lst = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.txtCari = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.menu = new System.Windows.Forms.ListView();
            this.lbltotal = new System.Windows.Forms.Label();
            this.cbtunda = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.lblColumn = new System.Windows.Forms.Label();
            this.txtbiaya = new System.Windows.Forms.TextBox();
            this.control = new System.Windows.Forms.Panel();
            this.btntunda = new System.Windows.Forms.PictureBox();
            this.txtkembalian = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtdibayar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCancel2 = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.label4 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.PictureBox();
            this.btnCancel = new System.Windows.Forms.PictureBox();
            this.ITEMS = new System.Windows.Forms.Panel();
            this.txtTOTALHARGA = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txttotalitem = new System.Windows.Forms.TextBox();
            this.lblavailable = new System.Windows.Forms.Label();
            this.btnCANCELITEM = new System.Windows.Forms.PictureBox();
            this.btnADDITEM = new System.Windows.Forms.PictureBox();
            this.txtITEM = new System.Windows.Forms.TextBox();
            this.shapeContainer2 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape4 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape5 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape6 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.control.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btntunda)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).BeginInit();
            this.ITEMS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCANCELITEM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnADDITEM)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.label1.Location = new System.Drawing.Point(587, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 54);
            this.label1.TabIndex = 5;
            this.label1.Text = "KASIR";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lst
            // 
            this.lst.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3});
            this.lst.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst.FullRowSelect = true;
            this.lst.GridLines = true;
            this.lst.Location = new System.Drawing.Point(14, 141);
            this.lst.MultiSelect = false;
            this.lst.Name = "lst";
            this.lst.Size = new System.Drawing.Size(503, 399);
            this.lst.TabIndex = 7;
            this.lst.UseCompatibleStateImageBehavior = false;
            this.lst.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ITEM";
            this.columnHeader1.Width = 250;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "QTY";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "HARGA";
            this.columnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader3.Width = 187;
            // 
            // txtCari
            // 
            this.txtCari.BackColor = System.Drawing.Color.SkyBlue;
            this.txtCari.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtCari.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtCari.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCari.ForeColor = System.Drawing.Color.White;
            this.txtCari.Location = new System.Drawing.Point(15, 99);
            this.txtCari.Name = "txtCari";
            this.txtCari.Size = new System.Drawing.Size(501, 26);
            this.txtCari.TabIndex = 12;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(13, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(250, 40);
            this.label9.TabIndex = 11;
            this.label9.Text = "CARI NAMA STOK";
            // 
            // menu
            // 
            this.menu.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.menu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menu.FullRowSelect = true;
            this.menu.GridLines = true;
            this.menu.Location = new System.Drawing.Point(523, 141);
            this.menu.MultiSelect = false;
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(319, 574);
            this.menu.TabIndex = 13;
            this.menu.UseCompatibleStateImageBehavior = false;
            this.menu.View = System.Windows.Forms.View.Tile;
            // 
            // lbltotal
            // 
            this.lbltotal.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.ForeColor = System.Drawing.Color.Black;
            this.lbltotal.Location = new System.Drawing.Point(15, 544);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(500, 109);
            this.lbltotal.TabIndex = 14;
            this.lbltotal.Text = "_";
            this.lbltotal.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cbtunda
            // 
            this.cbtunda.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.cbtunda.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbtunda.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtunda.Font = new System.Drawing.Font("Segoe UI", 21.75F);
            this.cbtunda.FormattingEnabled = true;
            this.cbtunda.Location = new System.Drawing.Point(13, 729);
            this.cbtunda.Name = "cbtunda";
            this.cbtunda.Size = new System.Drawing.Size(503, 48);
            this.cbtunda.TabIndex = 26;
            this.cbtunda.Visible = false;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(13, 686);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(268, 40);
            this.label10.TabIndex = 25;
            this.label10.Text = "TRANSAKSI TUNDA";
            this.label10.Visible = false;
            // 
            // lblColumn
            // 
            this.lblColumn.AutoSize = true;
            this.lblColumn.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColumn.ForeColor = System.Drawing.Color.White;
            this.lblColumn.Location = new System.Drawing.Point(12, 5);
            this.lblColumn.Name = "lblColumn";
            this.lblColumn.Size = new System.Drawing.Size(226, 40);
            this.lblColumn.TabIndex = 7;
            this.lblColumn.Text = "TOTAL BELANJA";
            // 
            // txtbiaya
            // 
            this.txtbiaya.BackColor = System.Drawing.Color.SkyBlue;
            this.txtbiaya.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtbiaya.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbiaya.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbiaya.ForeColor = System.Drawing.Color.White;
            this.txtbiaya.Location = new System.Drawing.Point(271, 6);
            this.txtbiaya.Name = "txtbiaya";
            this.txtbiaya.ReadOnly = true;
            this.txtbiaya.Size = new System.Drawing.Size(320, 39);
            this.txtbiaya.TabIndex = 8;
            this.txtbiaya.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // control
            // 
            this.control.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.control.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.control.Controls.Add(this.btntunda);
            this.control.Controls.Add(this.txtkembalian);
            this.control.Controls.Add(this.label3);
            this.control.Controls.Add(this.txtdibayar);
            this.control.Controls.Add(this.label2);
            this.control.Controls.Add(this.btnCancel2);
            this.control.Controls.Add(this.btnSave);
            this.control.Controls.Add(this.txtbiaya);
            this.control.Controls.Add(this.lblColumn);
            this.control.Controls.Add(this.shapeContainer1);
            this.control.Location = new System.Drawing.Point(0, -1000);
            this.control.Name = "control";
            this.control.Size = new System.Drawing.Size(863, 231);
            this.control.TabIndex = 9;
            this.control.Visible = false;
            // 
            // btntunda
            // 
            this.btntunda.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btntunda.Location = new System.Drawing.Point(594, 163);
            this.btntunda.Name = "btntunda";
            this.btntunda.Size = new System.Drawing.Size(59, 58);
            this.btntunda.TabIndex = 18;
            this.btntunda.TabStop = false;
            this.btntunda.Visible = false;
            // 
            // txtkembalian
            // 
            this.txtkembalian.BackColor = System.Drawing.Color.SkyBlue;
            this.txtkembalian.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtkembalian.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtkembalian.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtkembalian.ForeColor = System.Drawing.Color.White;
            this.txtkembalian.Location = new System.Drawing.Point(271, 114);
            this.txtkembalian.Name = "txtkembalian";
            this.txtkembalian.ReadOnly = true;
            this.txtkembalian.Size = new System.Drawing.Size(320, 39);
            this.txtkembalian.TabIndex = 17;
            this.txtkembalian.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(12, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(174, 40);
            this.label3.TabIndex = 16;
            this.label3.Text = "KEMBALIAN";
            // 
            // txtdibayar
            // 
            this.txtdibayar.BackColor = System.Drawing.Color.SkyBlue;
            this.txtdibayar.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtdibayar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdibayar.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdibayar.ForeColor = System.Drawing.Color.White;
            this.txtdibayar.Location = new System.Drawing.Point(271, 60);
            this.txtdibayar.Name = "txtdibayar";
            this.txtdibayar.Size = new System.Drawing.Size(320, 39);
            this.txtdibayar.TabIndex = 15;
            this.txtdibayar.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(12, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(222, 40);
            this.label2.TabIndex = 14;
            this.label2.Text = "UANG DIBAYAR";
            // 
            // btnCancel2
            // 
            this.btnCancel2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCancel2.Location = new System.Drawing.Point(529, 163);
            this.btnCancel2.Name = "btnCancel2";
            this.btnCancel2.Size = new System.Drawing.Size(59, 58);
            this.btnCancel2.TabIndex = 12;
            this.btnCancel2.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.Location = new System.Drawing.Point(464, 163);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(59, 58);
            this.btnSave.TabIndex = 11;
            this.btnSave.TabStop = false;
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape3,
            this.lineShape2,
            this.lineShape1});
            this.shapeContainer1.Size = new System.Drawing.Size(863, 231);
            this.shapeContainer1.TabIndex = 13;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.BorderColor = System.Drawing.Color.White;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 270;
            this.lineShape3.X2 = 590;
            this.lineShape3.Y1 = 155;
            this.lineShape3.Y2 = 155;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.Color.White;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 270;
            this.lineShape2.X2 = 590;
            this.lineShape2.Y1 = 101;
            this.lineShape2.Y2 = 101;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.White;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 271;
            this.lineShape1.X2 = 591;
            this.lineShape1.Y1 = 47;
            this.lineShape1.Y2 = 47;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(522, 98);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 40);
            this.label4.TabIndex = 27;
            this.label4.Text = "MENU";
            // 
            // btnAdd
            // 
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(21, 634);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(92, 81);
            this.btnAdd.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnAdd.TabIndex = 8;
            this.btnAdd.TabStop = false;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.BackColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(119, 658);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(59, 58);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.TabStop = false;
            // 
            // ITEMS
            // 
            this.ITEMS.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.ITEMS.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.ITEMS.Controls.Add(this.txtTOTALHARGA);
            this.ITEMS.Controls.Add(this.label5);
            this.ITEMS.Controls.Add(this.txttotalitem);
            this.ITEMS.Controls.Add(this.lblavailable);
            this.ITEMS.Controls.Add(this.btnCANCELITEM);
            this.ITEMS.Controls.Add(this.btnADDITEM);
            this.ITEMS.Controls.Add(this.txtITEM);
            this.ITEMS.Controls.Add(this.shapeContainer2);
            this.ITEMS.Location = new System.Drawing.Point(0, 140);
            this.ITEMS.Name = "ITEMS";
            this.ITEMS.Size = new System.Drawing.Size(863, 231);
            this.ITEMS.TabIndex = 28;
            this.ITEMS.Visible = false;
            // 
            // txtTOTALHARGA
            // 
            this.txtTOTALHARGA.BackColor = System.Drawing.Color.SkyBlue;
            this.txtTOTALHARGA.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtTOTALHARGA.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtTOTALHARGA.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTOTALHARGA.ForeColor = System.Drawing.Color.White;
            this.txtTOTALHARGA.Location = new System.Drawing.Point(271, 114);
            this.txtTOTALHARGA.Name = "txtTOTALHARGA";
            this.txtTOTALHARGA.ReadOnly = true;
            this.txtTOTALHARGA.Size = new System.Drawing.Size(320, 39);
            this.txtTOTALHARGA.TabIndex = 17;
            this.txtTOTALHARGA.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(12, 113);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(206, 40);
            this.label5.TabIndex = 16;
            this.label5.Text = "TOTAL HARGA";
            // 
            // txttotalitem
            // 
            this.txttotalitem.BackColor = System.Drawing.Color.SkyBlue;
            this.txttotalitem.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txttotalitem.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txttotalitem.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotalitem.ForeColor = System.Drawing.Color.White;
            this.txttotalitem.Location = new System.Drawing.Point(271, 60);
            this.txttotalitem.Name = "txttotalitem";
            this.txttotalitem.Size = new System.Drawing.Size(320, 39);
            this.txttotalitem.TabIndex = 15;
            this.txttotalitem.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblavailable
            // 
            this.lblavailable.AutoSize = true;
            this.lblavailable.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavailable.ForeColor = System.Drawing.Color.White;
            this.lblavailable.Location = new System.Drawing.Point(12, 59);
            this.lblavailable.Name = "lblavailable";
            this.lblavailable.Size = new System.Drawing.Size(127, 40);
            this.lblavailable.TabIndex = 14;
            this.lblavailable.Text = "JUMLAH";
            // 
            // btnCANCELITEM
            // 
            this.btnCANCELITEM.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCANCELITEM.Location = new System.Drawing.Point(531, 163);
            this.btnCANCELITEM.Name = "btnCANCELITEM";
            this.btnCANCELITEM.Size = new System.Drawing.Size(59, 58);
            this.btnCANCELITEM.TabIndex = 12;
            this.btnCANCELITEM.TabStop = false;
            // 
            // btnADDITEM
            // 
            this.btnADDITEM.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnADDITEM.Location = new System.Drawing.Point(466, 163);
            this.btnADDITEM.Name = "btnADDITEM";
            this.btnADDITEM.Size = new System.Drawing.Size(59, 58);
            this.btnADDITEM.TabIndex = 11;
            this.btnADDITEM.TabStop = false;
            // 
            // txtITEM
            // 
            this.txtITEM.BackColor = System.Drawing.Color.SkyBlue;
            this.txtITEM.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtITEM.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtITEM.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtITEM.ForeColor = System.Drawing.Color.White;
            this.txtITEM.Location = new System.Drawing.Point(3, 6);
            this.txtITEM.Name = "txtITEM";
            this.txtITEM.ReadOnly = true;
            this.txtITEM.Size = new System.Drawing.Size(588, 39);
            this.txtITEM.TabIndex = 8;
            this.txtITEM.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // shapeContainer2
            // 
            this.shapeContainer2.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer2.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer2.Name = "shapeContainer2";
            this.shapeContainer2.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape4,
            this.lineShape5,
            this.lineShape6});
            this.shapeContainer2.Size = new System.Drawing.Size(863, 231);
            this.shapeContainer2.TabIndex = 13;
            this.shapeContainer2.TabStop = false;
            // 
            // lineShape4
            // 
            this.lineShape4.BorderColor = System.Drawing.Color.White;
            this.lineShape4.Name = "lineShape3";
            this.lineShape4.X1 = 270;
            this.lineShape4.X2 = 590;
            this.lineShape4.Y1 = 155;
            this.lineShape4.Y2 = 155;
            // 
            // lineShape5
            // 
            this.lineShape5.BorderColor = System.Drawing.Color.White;
            this.lineShape5.Name = "lineShape2";
            this.lineShape5.X1 = 270;
            this.lineShape5.X2 = 590;
            this.lineShape5.Y1 = 101;
            this.lineShape5.Y2 = 101;
            // 
            // lineShape6
            // 
            this.lineShape6.BorderColor = System.Drawing.Color.White;
            this.lineShape6.Name = "lineShape1";
            this.lineShape6.X1 = 5;
            this.lineShape6.X2 = 591;
            this.lineShape6.Y1 = 47;
            this.lineShape6.Y2 = 47;
            // 
            // KASIR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.ITEMS);
            this.Controls.Add(this.control);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lst);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtCari);
            this.Controls.Add(this.cbtunda);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.lbltotal);
            this.Name = "KASIR";
            this.Size = new System.Drawing.Size(863, 796);
            this.control.ResumeLayout(false);
            this.control.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btntunda)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).EndInit();
            this.ITEMS.ResumeLayout(false);
            this.ITEMS.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnCANCELITEM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnADDITEM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lst;
        private System.Windows.Forms.PictureBox btnAdd;
        private System.Windows.Forms.PictureBox btnCancel;
        private System.Windows.Forms.TextBox txtCari;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ListView menu;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.ComboBox cbtunda;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblColumn;
        private System.Windows.Forms.TextBox txtbiaya;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.PictureBox btnCancel2;
        private System.Windows.Forms.Panel control;
        private System.Windows.Forms.TextBox txtkembalian;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtdibayar;
        private System.Windows.Forms.Label label2;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.PictureBox btntunda;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel ITEMS;
        private System.Windows.Forms.TextBox txtTOTALHARGA;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txttotalitem;
        private System.Windows.Forms.Label lblavailable;
        private System.Windows.Forms.PictureBox btnCANCELITEM;
        private System.Windows.Forms.PictureBox btnADDITEM;
        private System.Windows.Forms.TextBox txtITEM;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape4;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape5;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape6;
    }
}
