﻿namespace POS.CTL
{
    partial class PENGGUNA
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lst = new System.Windows.Forms.ListView();
            this.control = new System.Windows.Forms.Panel();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnDeleteModul = new System.Windows.Forms.PictureBox();
            this.btnAddModul = new System.Windows.Forms.PictureBox();
            this.cbmodul = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtfirstname = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPass = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.PictureBox();
            this.btnCancel2 = new System.Windows.Forms.PictureBox();
            this.btnSave = new System.Windows.Forms.PictureBox();
            this.txtPengguna = new System.Windows.Forms.TextBox();
            this.lblColumn = new System.Windows.Forms.Label();
            this.shapeContainer1 = new Microsoft.VisualBasic.PowerPacks.ShapeContainer();
            this.lineShape3 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape2 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.lineShape1 = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.line = new Microsoft.VisualBasic.PowerPacks.LineShape();
            this.btnCancel = new System.Windows.Forms.PictureBox();
            this.btnAdd = new System.Windows.Forms.PictureBox();
            this.control.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeleteModul)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddModul)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.label1.Location = new System.Drawing.Point(587, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 54);
            this.label1.TabIndex = 5;
            this.label1.Text = "PENGGUNA";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lst
            // 
            this.lst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lst.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst.FullRowSelect = true;
            this.lst.GridLines = true;
            this.lst.Location = new System.Drawing.Point(14, 205);
            this.lst.MultiSelect = false;
            this.lst.Name = "lst";
            this.lst.Size = new System.Drawing.Size(828, 372);
            this.lst.TabIndex = 7;
            this.lst.UseCompatibleStateImageBehavior = false;
            this.lst.View = System.Windows.Forms.View.Details;
            // 
            // control
            // 
            this.control.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.control.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.control.Controls.Add(this.listView1);
            this.control.Controls.Add(this.btnDeleteModul);
            this.control.Controls.Add(this.btnAddModul);
            this.control.Controls.Add(this.cbmodul);
            this.control.Controls.Add(this.label2);
            this.control.Controls.Add(this.txtemail);
            this.control.Controls.Add(this.label5);
            this.control.Controls.Add(this.txtfirstname);
            this.control.Controls.Add(this.label4);
            this.control.Controls.Add(this.txtPass);
            this.control.Controls.Add(this.label3);
            this.control.Controls.Add(this.btnDelete);
            this.control.Controls.Add(this.btnCancel2);
            this.control.Controls.Add(this.btnSave);
            this.control.Controls.Add(this.txtPengguna);
            this.control.Controls.Add(this.lblColumn);
            this.control.Controls.Add(this.shapeContainer1);
            this.control.Location = new System.Drawing.Point(0, 120);
            this.control.Name = "control";
            this.control.Size = new System.Drawing.Size(842, 407);
            this.control.TabIndex = 9;
            this.control.Visible = false;
            // 
            // listView1
            // 
            this.listView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listView1.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.Location = new System.Drawing.Point(649, 161);
            this.listView1.MultiSelect = false;
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(186, 238);
            this.listView1.TabIndex = 27;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // btnDeleteModul
            // 
            this.btnDeleteModul.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnDeleteModul.Location = new System.Drawing.Point(714, 92);
            this.btnDeleteModul.Name = "btnDeleteModul";
            this.btnDeleteModul.Size = new System.Drawing.Size(59, 58);
            this.btnDeleteModul.TabIndex = 25;
            this.btnDeleteModul.TabStop = false;
            // 
            // btnAddModul
            // 
            this.btnAddModul.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnAddModul.Location = new System.Drawing.Point(649, 92);
            this.btnAddModul.Name = "btnAddModul";
            this.btnAddModul.Size = new System.Drawing.Size(59, 58);
            this.btnAddModul.TabIndex = 24;
            this.btnAddModul.TabStop = false;
            // 
            // cbmodul
            // 
            this.cbmodul.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbmodul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbmodul.Font = new System.Drawing.Font("Segoe UI", 21.75F);
            this.cbmodul.FormattingEnabled = true;
            this.cbmodul.Location = new System.Drawing.Point(649, 38);
            this.cbmodul.Name = "cbmodul";
            this.cbmodul.Size = new System.Drawing.Size(540, 48);
            this.cbmodul.TabIndex = 22;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(642, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 40);
            this.label2.TabIndex = 26;
            this.label2.Text = "MODUL";
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.SkyBlue;
            this.txtemail.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtemail.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtemail.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.ForeColor = System.Drawing.Color.White;
            this.txtemail.Location = new System.Drawing.Point(20, 284);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(602, 39);
            this.txtemail.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(21, 249);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 40);
            this.label5.TabIndex = 20;
            this.label5.Text = "EMAIL";
            // 
            // txtfirstname
            // 
            this.txtfirstname.BackColor = System.Drawing.Color.SkyBlue;
            this.txtfirstname.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtfirstname.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtfirstname.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfirstname.ForeColor = System.Drawing.Color.White;
            this.txtfirstname.Location = new System.Drawing.Point(20, 201);
            this.txtfirstname.Name = "txtfirstname";
            this.txtfirstname.Size = new System.Drawing.Size(602, 39);
            this.txtfirstname.TabIndex = 19;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(19, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(203, 40);
            this.label4.TabIndex = 18;
            this.label4.Text = "NAMA DEPAN";
            // 
            // txtPass
            // 
            this.txtPass.BackColor = System.Drawing.Color.SkyBlue;
            this.txtPass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPass.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPass.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPass.ForeColor = System.Drawing.Color.White;
            this.txtPass.Location = new System.Drawing.Point(19, 120);
            this.txtPass.Name = "txtPass";
            this.txtPass.Size = new System.Drawing.Size(602, 39);
            this.txtPass.TabIndex = 17;
            this.txtPass.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(19, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(180, 40);
            this.label3.TabIndex = 16;
            this.label3.Text = "KATA KUNCI";
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnDelete.Location = new System.Drawing.Point(137, 338);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(59, 58);
            this.btnDelete.TabIndex = 14;
            this.btnDelete.TabStop = false;
            // 
            // btnCancel2
            // 
            this.btnCancel2.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnCancel2.Location = new System.Drawing.Point(72, 338);
            this.btnCancel2.Name = "btnCancel2";
            this.btnCancel2.Size = new System.Drawing.Size(59, 58);
            this.btnCancel2.TabIndex = 12;
            this.btnCancel2.TabStop = false;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnSave.Location = new System.Drawing.Point(7, 338);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(59, 58);
            this.btnSave.TabIndex = 11;
            this.btnSave.TabStop = false;
            // 
            // txtPengguna
            // 
            this.txtPengguna.BackColor = System.Drawing.Color.SkyBlue;
            this.txtPengguna.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtPengguna.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtPengguna.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPengguna.ForeColor = System.Drawing.Color.White;
            this.txtPengguna.Location = new System.Drawing.Point(19, 38);
            this.txtPengguna.Name = "txtPengguna";
            this.txtPengguna.Size = new System.Drawing.Size(602, 39);
            this.txtPengguna.TabIndex = 8;
            // 
            // lblColumn
            // 
            this.lblColumn.AutoSize = true;
            this.lblColumn.Font = new System.Drawing.Font("Segoe UI", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblColumn.ForeColor = System.Drawing.Color.White;
            this.lblColumn.Location = new System.Drawing.Point(19, 0);
            this.lblColumn.Name = "lblColumn";
            this.lblColumn.Size = new System.Drawing.Size(171, 40);
            this.lblColumn.TabIndex = 7;
            this.lblColumn.Text = "PENGGUNA";
            // 
            // shapeContainer1
            // 
            this.shapeContainer1.Location = new System.Drawing.Point(0, 0);
            this.shapeContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.shapeContainer1.Name = "shapeContainer1";
            this.shapeContainer1.Shapes.AddRange(new Microsoft.VisualBasic.PowerPacks.Shape[] {
            this.lineShape3,
            this.lineShape2,
            this.lineShape1,
            this.line});
            this.shapeContainer1.Size = new System.Drawing.Size(842, 407);
            this.shapeContainer1.TabIndex = 13;
            this.shapeContainer1.TabStop = false;
            // 
            // lineShape3
            // 
            this.lineShape3.BorderColor = System.Drawing.Color.White;
            this.lineShape3.Name = "lineShape3";
            this.lineShape3.X1 = 19;
            this.lineShape3.X2 = 617;
            this.lineShape3.Y1 = 242;
            this.lineShape3.Y2 = 242;
            // 
            // lineShape2
            // 
            this.lineShape2.BorderColor = System.Drawing.Color.White;
            this.lineShape2.Name = "lineShape2";
            this.lineShape2.X1 = 19;
            this.lineShape2.X2 = 617;
            this.lineShape2.Y1 = 161;
            this.lineShape2.Y2 = 161;
            // 
            // lineShape1
            // 
            this.lineShape1.BorderColor = System.Drawing.Color.White;
            this.lineShape1.Name = "lineShape1";
            this.lineShape1.X1 = 19;
            this.lineShape1.X2 = 617;
            this.lineShape1.Y1 = 79;
            this.lineShape1.Y2 = 79;
            // 
            // line
            // 
            this.line.BorderColor = System.Drawing.Color.White;
            this.line.Name = "line";
            this.line.X1 = 21;
            this.line.X2 = 619;
            this.line.Y1 = 325;
            this.line.Y2 = 325;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(79, 122);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(59, 58);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.TabStop = false;
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(14, 122);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(59, 58);
            this.btnAdd.TabIndex = 8;
            this.btnAdd.TabStop = false;
            // 
            // PENGGUNA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.control);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lst);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnCancel);
            this.Name = "PENGGUNA";
            this.Size = new System.Drawing.Size(863, 594);
            this.control.ResumeLayout(false);
            this.control.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnDeleteModul)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAddModul)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnDelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnSave)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnAdd)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lst;
        private System.Windows.Forms.PictureBox btnAdd;
        private System.Windows.Forms.Panel control;
        private System.Windows.Forms.PictureBox btnCancel;
        private System.Windows.Forms.Label lblColumn;
        private System.Windows.Forms.PictureBox btnCancel2;
        private System.Windows.Forms.PictureBox btnSave;
        private System.Windows.Forms.TextBox txtPengguna;
        private Microsoft.VisualBasic.PowerPacks.ShapeContainer shapeContainer1;
        private Microsoft.VisualBasic.PowerPacks.LineShape line;
        private System.Windows.Forms.PictureBox btnDelete;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtfirstname;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.Label label3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape3;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape2;
        private Microsoft.VisualBasic.PowerPacks.LineShape lineShape1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.PictureBox btnDeleteModul;
        private System.Windows.Forms.PictureBox btnAddModul;
        private System.Windows.Forms.ComboBox cbmodul;
        private System.Windows.Forms.Label label2;
    }
}
