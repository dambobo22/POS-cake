﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS.CTL
{
    public partial class PENGGUNA : UserControl
    {
        kp _kp;
        main m;
        bool isupdate = false;       
        string oldName = "";
        public PENGGUNA(kp _k,main _main)
        {
            InitializeComponent();            
            _kp = _k;            
            m = _main;
            btnAdd.Image = _kp.ImgAdd;
            btnCancel.Image = _kp.ImgCancel;
            btnSave.Image = _kp.ImgSave;
            btnCancel2.Image = _kp.ImgCancel;
            btnAddModul.Image = _kp.ImgAdd;
            btnDeleteModul.Image = _kp.ImgDelete;
            _kp.combo("select roleName from tRole where isActive = 1", cbmodul);
            LoadUser();
            btnAdd.Click += btnAdd_Click;
            btnCancel.Click += btnCancel_Click;
            btnCancel2.Click += btnCancel_Click;
            btnSave.Click += btnSave_Click;
            btnDelete.Click += btnDelete_Click;
            btnAddModul.Click += btnAddModul_Click;
            btnDeleteModul.Click += btnDeleteModul_Click;
            lst.DoubleClick += lst_DoubleClick;    
        }
        void btnDeleteModul_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems != null)
            {
                m.MessageInfo(main.MessageType.Alert, String.Format("MODUL {0} SUDAH DIHAPUS", cbmodul.Text), 100);
                listView1.Items.Remove(listView1.SelectedItems[0]);
                cbmodul.Focus();
            }
            else
            {
                m.MessageInfo(main.MessageType.Alert, "PILIH MODUL TERLEBIH DULU", 100);
                cbmodul.Focus();
            }
        }
        void btnAddModul_Click(object sender, EventArgs e)
        {
            if (cbmodul.Text != "")
            {
                bool isexist = false;
                foreach (ListViewItem l in listView1.Items)
                {
                    if (l.Text == cbmodul.Text)
                    {
                        isexist = true;
                    }
                }
                if (!isexist)
                {
                    listView1.Items.Add(new ListViewItem(new String[] { cbmodul.Text }));
                }
                else
                {
                    m.MessageInfo(main.MessageType.Alert, String.Format("MODUL {0} SUDAH ADA",cbmodul.Text), 100);
                    cbmodul.Focus();
                }
            }
            else
            {
                m.MessageInfo(main.MessageType.Alert, "PILIH MODUL TERLEBIH DULU", 100);
                cbmodul.Focus();
            }
        }
        void btnDelete_Click(object sender, EventArgs e)
        {
            if (btnDelete.Image == _kp.ImgDelete)
            {
                if (txtPengguna.Text == "")
                {
                    m.MessageInfo(main.MessageType.Alert, txtPengguna.Text + " TIDAK BOLEH KOSONG", 100);
                }
                if (txtPengguna.Text == "ADMIN")
                {
                    m.MessageInfo(main.MessageType.Alert, txtPengguna.Text + " TIDAK BOLEH DIHAPUS", 100);
                }
                if (lst.Items.Count == 1)
                {
                    m.MessageInfo(main.MessageType.Alert, "TAMBAH PENGGUNA LAIN TERLEBIH DULU", 100);
                }
                else
                {
                    string deletequery = "";
                    deletequery = String.Format("delete from tUser where userName = '{0}' delete from tUserRole where userName = '{0}' and userName NOT IN('{1}')", txtPengguna.Text,_kp.useractive);

                    if (_kp.CUD(deletequery, m.username))
                    {
                        m.MessageInfo(main.MessageType.Success, String.Format("PENGGUNA {0} BERHASIL DIHAPUS", txtPengguna.Text), 100);
                        Clear(sender);
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    }

                }
            }
        }
        void lst_DoubleClick(object sender, EventArgs e)
        {
            if(lst.SelectedItems != null)
            {
                btnAdd.Visible = false;
                btnCancel.Visible = false;
                txtPengguna.Text = oldName = lst.SelectedItems[0].Text;
                DataTable pass = _kp.S(String.Format("select passWord from tUser where userName = '{0}'",txtPengguna.Text));
                _kp.list(String.Format("select roleName as MODUL from tUserRole where userName = '{0}' order by createdDate",txtPengguna.Text),listView1,500);
                if (pass.Rows.Count > 0)
                {
                    txtPass.Text = pass.Rows[0].ItemArray[0].ToString();
                }
                else
                {
                    txtPass.Text = "";
                }               
                txtfirstname.Text = lst.SelectedItems[0].SubItems[1].Text;
                txtemail.Text = lst.SelectedItems[0].SubItems[2].Text;
                control.Location = new Point(0, 120);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2));
                cbmodul.Enabled = true;
                btnDelete.Image = _kp.ImgDelete;                             
                isupdate = true;
                txtPengguna.Enabled = false;
                
            }
        }
        void btnSave_Click(object sender, EventArgs e)
        {
            if (listView1.Items.Count <= 0)
            {
                m.MessageInfo(main.MessageType.Alert, "PILIH PENGGUNA TERLEBIH DULU", 100);
            }
            else if(txtPengguna.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "NAMA PENGGUNA TIDAK BOLEH KOSONG", 100);
                txtPengguna.Focus();
            }
            else if (txtPass.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "PASSWORD TIDAK BOLEH KOSONG", 100);
                txtPass.Focus();
            }
            else if (txtfirstname.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "NAMA DEPAN TIDAK BOLEH KOSONG", 100);
                txtfirstname.Focus();
            }
            else if (txtemail.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "EMAIL TIDAK BOLEH KOSONG", 100);
                txtemail.Focus();
            }
            else if (_kp.ValidateInput(kp.InputType.Email,txtemail.Text) != txtemail.Text)
            {
                m.MessageInfo(main.MessageType.Alert, "EMAIL FORMAT TIDAK VALID", 100);
                txtemail.Focus();
            }            
            else
            {
                string insertquery = "";
                string updatequery = "";
                string modulquery = "";
                string _modul = "";

                DataTable cekdata;
                foreach (ListViewItem l in listView1.Items)
                {
                    _modul += String.Format("'{0}',", l.Text);
                }
                _modul = _modul.Substring(0, _modul.Length - 1);
                modulquery = String.Format("delete from tUserRole where userName = '{0}' " +
                                           "insert into tUserRole " +
                                           "select '{0}',roleName,GETDATE() from tRole where roleName in({1}) ",txtPengguna.Text,_modul);
                if (isupdate)
                {
                    updatequery = String.Format("update tUser set email = '{0}',FirstName = '{1}',passWord = '{2}',modifiedDate = GETDATE() where userName = '{3}'", txtemail.Text,txtfirstname.Text, txtPass.Text, txtPengguna.Text);
                    updatequery += Environment.NewLine + modulquery;
                    if (_kp.CUD(updatequery, m.username))
                    {
                        m.MessageInfo(main.MessageType.Success, String.Format("PENGGUNA {0} BERHASIL DIRUBAH", txtPengguna.Text), 100);
                        Clear(sender);
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    }
                }
                else
                {

                    insertquery = String.Format("insert into tUser values('{0}','{1}','{2}','{3}',GETDATE(),NULL,NULL)", txtPengguna.Text,txtemail.Text,txtfirstname.Text,txtPass.Text);
                    cekdata = _kp.S(String.Format("select * from tuser where userName = '{0}'", txtPengguna.Text));
                    if (cekdata.Rows.Count > 0)
                    {
                        m.MessageInfo(main.MessageType.Alert, String.Format("PENGGUNA {0} SUDAH ADA", txtPengguna.Text.ToUpper()), 100);
                        txtPengguna.SelectAll();
                    }
                    else
                    {
                        insertquery += Environment.NewLine + modulquery;
                        if (_kp.CUD(insertquery, m.username))
                        {
                            m.MessageInfo(main.MessageType.Success, String.Format("PENGGUNA {0} BERHASIL DITAMBAHKAN", txtPengguna.Text.ToUpper()), 100);
                            Clear(sender);
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                        }
                    }
                }
            }
        }
        void btnCancel_Click(object sender, EventArgs e)
        {
            control.Location = new Point(0, -1200);
            control.Size = new Size(this.Width, control.Height);
            cbmodul.Enabled = true;
            _kp.combo("select roleName from tRole where isActive = 1", cbmodul);
            cbmodul.SelectedIndex = -1;
            txtPengguna.Text = "";           
            btnDelete.Image = null;
            isupdate = false;
            txtPengguna.Text = "";
            txtemail.Text = "";
            txtfirstname.Text = "";
            txtPass.Text = "";
            txtPengguna.Enabled = true;
            oldName = "";
            listView1.Clear();
            btnAdd.Visible = true;
            btnCancel.Visible = true;
            LoadUser();
        }
        void Clear(object sender)
        {
            control.Location = new Point(0, -1200);
            control.Size = new Size(this.Width, control.Height);           
            cbmodul.Enabled = true;
            _kp.combo("select roleName from tRole where isActive = 1", cbmodul);
            txtPengguna.Text = "";           
            btnDelete.Image = null;
            isupdate = false;
            txtPengguna.Enabled = true;
            oldName = "";
            txtPengguna.Text = "";
            txtemail.Text = "";
            txtfirstname.Text = "";
            txtPass.Text = "";
            listView1.Clear();
            btnAdd.Visible = true;
            btnCancel.Visible = true;
            LoadUser();
            
        }
        void btnAdd_Click(object sender, EventArgs e)
        {
                control.Location = new Point(0, 120);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2));
                cbmodul.Enabled = true;
                txtPengguna.Enabled = true;
                listView1.Columns.Add("MODUL", 500);
                txtPengguna.Focus();   
        } 
        void LoadUser()
        {

            _kp.list(String.Format("select userName as PENGGUNA,FirstName as NAMA_DEPAN,email as EMAIL,CONVERT(VARCHAR(100),lastLoginDate,120) as LOGIN_TERAKHIR from tUser where userName NOT IN('{0}')",_kp.useractive), lst, 300);
         if (lst.Items.Count == 0) { m.MessageInfo(main.MessageType.Warning, "TABEL KOSONG, SILAHKAN TAMBAH DATA PENGGUNA", 100); }
        }

    }
}
