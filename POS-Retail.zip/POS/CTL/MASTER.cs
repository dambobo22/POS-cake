﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS.CTL
{
    public partial class MASTER : UserControl
    {
        kp _kp;
        main m;
        bool isupdate = false;
        bool isclicked = false;
        string oldName = "";
        public MASTER(kp _k,main _main)
        {
            InitializeComponent();            
            _kp = _k;            
            m = _main;
            btnAdd.Image = _kp.ImgAdd;
            btnCancel.Image = _kp.ImgCancel;
            btnSave.Image = _kp.ImgSave;
            btnCancel2.Image = _kp.ImgCancel;
            btnCheck.Image = _kp.ImgActive;
            cbMaster.Items.Add("RASA");
            cbMaster.Items.Add("KATEGORI");
            cbMaster.Items.Add("UKURAN");
            cbMaster.Items.Add("SATUAN");
            cbMaster.Items.Add("MODUL");

            cbMaster.SelectedIndexChanged += cbMaster_SelectedIndexChanged;
            btnAdd.Click += btnAdd_Click;
            btnCancel.Click += btnCancel_Click;
            btnCancel2.Click += btnCancel_Click;
            btnSave.Click += btnSave_Click;
            btnDelete.Click += btnDelete_Click;
            lst.DoubleClick += lst_DoubleClick;
            btnCheck.MouseEnter += btnCheck_MouseEnter;
            btnCheck.MouseLeave += btnCheck_MouseLeave;
            btnCheck.MouseDown += btnCheck_MouseDown;

        }

        void LoadPM(ComboBox cb)
        {
            DataTable data = _kp.S("select pmName from tPacketMeasurement");
            cb.Items.Clear();
            if (data.Rows.Count > 0)
            {
                foreach (DataRow r in data.Rows)
                {
                    cb.Items.Add(r.ItemArray[0].ToString());
                }
            }
        }
        void btnCheck_MouseDown(object sender, MouseEventArgs e)
        {
            if (isclicked)
            {
                btnCheck.Image = _kp.ImgActive;
                isclicked = false;
            }
            else
            {
                btnCheck.Image = _kp.ImgClicked;
                isclicked = true;
            }
        }

        void btnCheck_MouseLeave(object sender, EventArgs e)
        {
            if (isclicked)
            {
                btnCheck.Image = _kp.ImgClicked;                
            }
            else
            {
                btnCheck.Image = _kp.ImgActive;
            }
        }

        void btnCheck_MouseEnter(object sender, EventArgs e)
        {
            if (isclicked)
            {
                btnCheck.Image = _kp.ImgClicked; 
            }
            else
            {
                btnCheck.Image = _kp.ImgHover;
                
            }
        }

        void btnDelete_Click(object sender, EventArgs e)
        {
            if (btnDelete.Image == _kp.ImgDelete)
            {
                if (cbMaster.Text == "")
                {
                    m.MessageInfo(main.MessageType.Alert, "PILIH TABEL TERLEBIH DULU", 100);
                }
                else if (txtColumn.Text == "")
                {
                    m.MessageInfo(main.MessageType.Alert, cbMaster.Text + " TIDAK BOLEH KOSONG", 100);
                }
                else
                {
                    string deletequery = "";                   
                    string tablename = "";
                    string columnname = "";                    
                    switch (cbMaster.Text)
                    {
                        case "RASA": tablename = "tTaste"; columnname = "tasteName"; break;
                        case "KATEGORI": tablename = "tCategory"; columnname = "categoryName"; break;
                        case "UKURAN": tablename = "tSize"; columnname = "sizeName"; break;
                        case "SATUAN": tablename = "tUOM"; columnname = "uomName"; break;
                        case "MODUL": tablename = "tRole"; columnname = "roleName"; break;
                    }
                    deletequery = String.Format("delete from {0} where {1} = '{2}'", tablename, columnname,txtColumn.Text.ToUpper());
                    
                        if (_kp.CUD(deletequery, m.username))
                        {
                            m.MessageInfo(main.MessageType.Success, String.Format("{0} {1} BERHASIL DIHAPUS", cbMaster.Text, txtColumn.Text.ToUpper()), 100);
                            Clear(sender);
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                        }
                    
                }
            }
        }

        void lst_DoubleClick(object sender, EventArgs e)
        {
            if(lst.SelectedItems != null)
            {
                txtColumn.Text = oldName = lst.SelectedItems[0].Text;
                isclicked = lst.SelectedItems[0].SubItems[1].Text == "AKTIF" ? true : false;
                if (isclicked)
                {
                    btnCheck.Image = _kp.ImgClicked; 
                }
                else
                {
                    btnCheck.Image = _kp.ImgActive; 
                }
                control.Location = new Point(0, -200);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2));
                cbMaster.Enabled = false;
                btnDelete.Image = _kp.ImgDelete;               
                if (cbMaster.Text != "KATEGORI")
                {
                    lblColumn.Text = String.Format("UBAH/HAPUS {0} ({1})", cbMaster.Text, oldName);
                    lblUOM.Visible = false;
                    cbUOM.Visible = false;
                }
                else
                {
                    lblColumn.Text = String.Format("UBAH/HAPUS {0} ({1})", cbMaster.Text, oldName);
                    lblUOM.Visible = true;
                    cbUOM.Visible = true;
                    LoadPM(cbUOM);
                    cbUOM.Text = lst.SelectedItems[0].SubItems[2].Text;
                }
                isupdate = true;
            }
        }

        void btnSave_Click(object sender, EventArgs e)
        {
            if (cbMaster.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "PILIH TABEL TERLEBIH DULU", 100);
            }
            else if(txtColumn.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, cbMaster.Text + " BARU TIDAK BOLEH KOSONG", 100);
            }
            else if (cbMaster.Text == "KATEGORI" && cbUOM.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "UOM TIDAK BOLEH KOSONG", 100);
            }
            else
            {
                string insertquery = "";
                string updatequery = "";
                DataTable cekdata;
                string tablename = "";
                string columnname = "";
                string columnname2 = "";
                switch (cbMaster.Text)
                {
                    case "RASA": tablename = "tTaste"; columnname = "tasteName"; break;
                    case "KATEGORI": tablename = "tCategory"; columnname = "categoryName"; columnname2 = "pmId"; break;
                    case "UKURAN": tablename = "tSize"; columnname = "sizeName"; break;
                    case "SATUAN": tablename = "tUOM"; columnname = "uomName"; break;
                    case "MODUL": tablename = "tRole"; columnname = "roleName"; break;
                }
                int active = isclicked ? 1 : 0;
                if (isupdate)
                {
                    if (tablename != "tCategory")
                    {
                        updatequery = String.Format("update {0} set {1} = '{3}',isActive = {4},modifiedDate = GETDATE() where {1} = '{2}'", tablename, columnname, oldName, txtColumn.Text.ToUpper(), active);
                    }
                    else
                    {
                        DataTable pmid = _kp.S(String.Format("select pmId from tPacketMeasurement where pmName = '{0}'", cbUOM.Text));
                        if (pmid.Rows.Count > 0)
                        {
                            updatequery = String.Format("update {0} set {1} = '{3}',{5} = '{6}',isActive = {4},modifiedDate = GETDATE() where {1} = '{2}'", tablename, columnname, oldName, txtColumn.Text.ToUpper(), active, columnname2, pmid.Rows[0].ItemArray[0].ToString());
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "PM ID KOSONG, HUBUNGI ADMIN ANDA", 200);
                        }
                        
                    }
                    if (_kp.CUD(updatequery, m.username))
                    {
                        m.MessageInfo(main.MessageType.Success, String.Format("{0} {1} BERHASIL DIRUBAH", cbMaster.Text, oldName), 100);
                        Clear(sender);
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    }
                }
                else
                {
                    if (tablename == "tCategory")
                    {
                        DataTable pmid = _kp.S(String.Format("select pmId from tPacketMeasurement where pmName = '{0}'", cbUOM.Text));
                        if (pmid.Rows.Count > 0)
                        {
                            insertquery = String.Format("insert into {0} values(NEWID(),'{1}','{3}',{2},GETDATE(),NULL)", tablename, txtColumn.Text.ToUpper(), active, pmid.Rows[0].ItemArray[0].ToString());
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "PM ID KOSONG, HUBUNGI ADMIN ANDA", 200);
                        }
                    }
                    else
                    {
                        insertquery = String.Format("insert into {0} values(NEWID(),'{1}',{2},GETDATE(),NULL)", tablename, txtColumn.Text.ToUpper(), active);
                    }
                    cekdata = _kp.S(String.Format("select A.NAME from( " +
                                                  "select tasteName as NAME from tTaste " +
                                                  "UNION " +
                                                  "select categoryName as NAME from tCategory " +
                                                  "UNION " +
                                                  "select sizeName as NAME from tSize " +
                                                  "UNION " +
                                                  "select uomName as NAME from tUOM " +
                                                  "UNION " +
                                                  "select roleName as NAME from tRole " +
                                                  ") A where A.NAME = '{0}'", txtColumn.Text.ToUpper()));
                    if (cekdata.Rows.Count > 0)
                    {
                        m.MessageInfo(main.MessageType.Alert, String.Format("{0} {1} SUDAH ADA", cbMaster.Text, txtColumn.Text.ToUpper()), 100);
                        txtColumn.SelectAll();
                    }
                    else
                    {
                        if (_kp.CUD(insertquery, m.username))
                        {
                            m.MessageInfo(main.MessageType.Success, String.Format("{0} {1} BARU BERHASIL DITAMBAHKAN", cbMaster.Text, txtColumn.Text.ToUpper()), 100);
                            Clear(sender);
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                        }
                    }
                }
            }
        }

        void btnCancel_Click(object sender, EventArgs e)
        {
            control.Location = new Point(0, -200);
            control.Size = new Size(this.Width, control.Height);
            cbMaster.Enabled = true;
            cbMaster.SelectedIndex = -1;
            txtColumn.Text = "";
            lblColumn.Text = "";
            btnDelete.Image = null;
            isupdate = false;
            oldName = "";
            btnCheck.Image = _kp.ImgActive;
            isclicked = false;
            lblUOM.Visible = false;
            cbUOM.Visible = false;
        }

        void Clear(object sender)
        {
            control.Location = new Point(0, -200);
            control.Size = new Size(this.Width, control.Height);
            cbMaster.Enabled = true;           
            txtColumn.Text = "";
            lblColumn.Text = "";
            btnDelete.Image = null;
            isupdate = false;
            oldName = "";
            btnCheck.Image = _kp.ImgActive;
            isclicked = false;
            cbMaster_SelectedIndexChanged(sender, null);
            lblUOM.Visible = false;
            cbUOM.Visible = false;
        }

        void btnAdd_Click(object sender, EventArgs e)
        {
            
            if (cbMaster.Enabled && cbMaster.Text != "")
            {
                control.Location = new Point(0, -200);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2));
                cbMaster.Enabled = false;
                if (cbMaster.Text != "KATEGORI")
                {
                    lblColumn.Text = cbMaster.Text + " BARU";
                    lblUOM.Visible = false;
                    cbUOM.Visible = false;
                }
                else
                {
                    lblColumn.Text = cbMaster.Text + " BARU";
                    lblUOM.Visible = true;
                    cbUOM.Visible = true;
                    cbUOM.Items.Clear();
                    cbUOM.Items.Add("SATUAN");
                    cbUOM.Items.Add("UKURAN");
                }


                
                btnCheck.Image = _kp.ImgClicked;
                isclicked = true;
            }
            
        }

        void cbMaster_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(cbMaster.Text)
            {
                case "RASA":
                    _kp.list("select tasteName as RASA,case isActive when 1 then 'AKTIF' ELSE 'NON AKTIF' END as STATUS from tTaste order by tasteName", lst,500);
                    if (lst.Items.Count == 0) { m.MessageInfo(main.MessageType.Warning, "TABEL KOSONG, SILAHKAN TAMBAH DATA " + cbMaster.Text, 100); }
                    break;
                case "KATEGORI":
                    _kp.list("select categoryName as KATEGORI,case isActive when 1 then 'AKTIF' ELSE 'NON AKTIF' END as STATUS,B.pmName as UOM from tCategory A inner join tPacketMeasurement B ON A.pmId = B.pmId order by categoryName", lst, 500);
                    if (lst.Items.Count == 0) { m.MessageInfo(main.MessageType.Warning, "TABEL KOSONG, SILAHKAN TAMBAH DATA " + cbMaster.Text, 100); }
                    break;
                case "UKURAN":
                    _kp.list("select sizeName as UKURAN,case isActive when 1 then 'AKTIF' ELSE 'NON AKTIF' END as STATUS from tSize order by sizeName", lst,500);
                    if (lst.Items.Count == 0) { m.MessageInfo(main.MessageType.Warning, "TABEL KOSONG, SILAHKAN TAMBAH DATA " + cbMaster.Text, 100); }
                    break;
                case "SATUAN":
                    _kp.list("select uomName as SATUAN,case isActive when 1 then 'AKTIF' ELSE 'NON AKTIF' END as STATUS from tUOM order by uomName", lst,500);
                    if (lst.Items.Count == 0) { m.MessageInfo(main.MessageType.Warning, "TABEL KOSONG, SILAHKAN TAMBAH DATA " + cbMaster.Text, 100); }
                    break;
                case "MODUL":
                    _kp.list("select roleName as MODUL,case isActive when 1 then 'AKTIF' ELSE 'NON AKTIF' END as STATUS from tRole order by roleName", lst, 500);
                    if (lst.Items.Count == 0) { m.MessageInfo(main.MessageType.Warning, "TABEL KOSONG, SILAHKAN TAMBAH DATA " + cbMaster.Text, 100); }
                    break;

            }
        }

    }
}
