﻿namespace POS.CTL
{
    partial class LAPORAN
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lst = new System.Windows.Forms.ListView();
            this.dtstart = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.lbldaripenjualan = new System.Windows.Forms.Label();
            this.dtend = new System.Windows.Forms.DateTimePicker();
            this.lblsampaipenjualan = new System.Windows.Forms.Label();
            this.cbjenisbarang = new System.Windows.Forms.ComboBox();
            this.rbbarang = new System.Windows.Forms.RadioButton();
            this.rbpenjualan = new System.Windows.Forms.RadioButton();
            this.cbkategori = new System.Windows.Forms.ComboBox();
            this.lblbarang = new System.Windows.Forms.Label();
            this.btncari = new System.Windows.Forms.Button();
            this.btncetak = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.label1.Location = new System.Drawing.Point(587, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(273, 54);
            this.label1.TabIndex = 5;
            this.label1.Text = "LAPORAN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lst
            // 
            this.lst.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lst.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lst.FullRowSelect = true;
            this.lst.GridLines = true;
            this.lst.Location = new System.Drawing.Point(14, 314);
            this.lst.MultiSelect = false;
            this.lst.Name = "lst";
            this.lst.Size = new System.Drawing.Size(828, 263);
            this.lst.TabIndex = 7;
            this.lst.UseCompatibleStateImageBehavior = false;
            this.lst.View = System.Windows.Forms.View.Details;
            // 
            // dtstart
            // 
            this.dtstart.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dtstart.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtstart.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtstart.Location = new System.Drawing.Point(14, 268);
            this.dtstart.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.dtstart.MinDate = new System.DateTime(2015, 1, 1, 0, 0, 0, 0);
            this.dtstart.Name = "dtstart";
            this.dtstart.Size = new System.Drawing.Size(216, 39);
            this.dtstart.TabIndex = 8;
            this.dtstart.Visible = false;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI", 27.75F);
            this.label2.Location = new System.Drawing.Point(19, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(297, 54);
            this.label2.TabIndex = 9;
            this.label2.Text = "JENIS LAPORAN";
            // 
            // lbldaripenjualan
            // 
            this.lbldaripenjualan.AutoSize = true;
            this.lbldaripenjualan.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldaripenjualan.Location = new System.Drawing.Point(8, 233);
            this.lbldaripenjualan.Name = "lbldaripenjualan";
            this.lbldaripenjualan.Size = new System.Drawing.Size(67, 32);
            this.lbldaripenjualan.TabIndex = 10;
            this.lbldaripenjualan.Text = "DARI";
            this.lbldaripenjualan.Visible = false;
            // 
            // dtend
            // 
            this.dtend.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dtend.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtend.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtend.Location = new System.Drawing.Point(236, 268);
            this.dtend.MaxDate = new System.DateTime(2020, 12, 31, 0, 0, 0, 0);
            this.dtend.MinDate = new System.DateTime(2015, 1, 1, 0, 0, 0, 0);
            this.dtend.Name = "dtend";
            this.dtend.Size = new System.Drawing.Size(230, 39);
            this.dtend.TabIndex = 11;
            this.dtend.Visible = false;
            // 
            // lblsampaipenjualan
            // 
            this.lblsampaipenjualan.AutoSize = true;
            this.lblsampaipenjualan.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsampaipenjualan.Location = new System.Drawing.Point(230, 233);
            this.lblsampaipenjualan.Name = "lblsampaipenjualan";
            this.lblsampaipenjualan.Size = new System.Drawing.Size(99, 32);
            this.lblsampaipenjualan.TabIndex = 12;
            this.lblsampaipenjualan.Text = "SAMPAI";
            this.lblsampaipenjualan.Visible = false;
            // 
            // cbjenisbarang
            // 
            this.cbjenisbarang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbjenisbarang.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.cbjenisbarang.FormattingEnabled = true;
            this.cbjenisbarang.Location = new System.Drawing.Point(14, 136);
            this.cbjenisbarang.Name = "cbjenisbarang";
            this.cbjenisbarang.Size = new System.Drawing.Size(236, 40);
            this.cbjenisbarang.TabIndex = 14;
            this.cbjenisbarang.Visible = false;
            // 
            // rbbarang
            // 
            this.rbbarang.AutoSize = true;
            this.rbbarang.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.rbbarang.Location = new System.Drawing.Point(14, 97);
            this.rbbarang.Name = "rbbarang";
            this.rbbarang.Size = new System.Drawing.Size(236, 36);
            this.rbbarang.TabIndex = 16;
            this.rbbarang.TabStop = true;
            this.rbbarang.Text = "LAPORAN BARANG";
            this.rbbarang.UseVisualStyleBackColor = true;
            // 
            // rbpenjualan
            // 
            this.rbpenjualan.AutoSize = true;
            this.rbpenjualan.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.rbpenjualan.Location = new System.Drawing.Point(14, 194);
            this.rbpenjualan.Name = "rbpenjualan";
            this.rbpenjualan.Size = new System.Drawing.Size(271, 36);
            this.rbpenjualan.TabIndex = 17;
            this.rbpenjualan.TabStop = true;
            this.rbpenjualan.Text = "LAPORAN PENJUALAN";
            this.rbpenjualan.UseVisualStyleBackColor = true;
            // 
            // cbkategori
            // 
            this.cbkategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbkategori.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.cbkategori.FormattingEnabled = true;
            this.cbkategori.Location = new System.Drawing.Point(270, 136);
            this.cbkategori.Name = "cbkategori";
            this.cbkategori.Size = new System.Drawing.Size(250, 40);
            this.cbkategori.TabIndex = 18;
            this.cbkategori.Visible = false;
            // 
            // lblbarang
            // 
            this.lblbarang.AutoSize = true;
            this.lblbarang.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.lblbarang.Location = new System.Drawing.Point(264, 101);
            this.lblbarang.Name = "lblbarang";
            this.lblbarang.Size = new System.Drawing.Size(123, 32);
            this.lblbarang.TabIndex = 19;
            this.lblbarang.Text = "KATEGORI";
            this.lblbarang.Visible = false;
            // 
            // btncari
            // 
            this.btncari.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btncari.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncari.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.btncari.Location = new System.Drawing.Point(618, 256);
            this.btncari.Name = "btncari";
            this.btncari.Size = new System.Drawing.Size(109, 51);
            this.btncari.TabIndex = 20;
            this.btncari.Text = "CARI";
            this.btncari.UseVisualStyleBackColor = true;
            // 
            // btncetak
            // 
            this.btncetak.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btncetak.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncetak.Font = new System.Drawing.Font("Segoe UI", 18F);
            this.btncetak.Location = new System.Drawing.Point(733, 256);
            this.btncetak.Name = "btncetak";
            this.btncetak.Size = new System.Drawing.Size(109, 51);
            this.btncetak.TabIndex = 21;
            this.btncetak.Text = "CETAK";
            this.btncetak.UseVisualStyleBackColor = true;
            // 
            // LAPORAN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.btncetak);
            this.Controls.Add(this.btncari);
            this.Controls.Add(this.lblbarang);
            this.Controls.Add(this.cbkategori);
            this.Controls.Add(this.rbpenjualan);
            this.Controls.Add(this.rbbarang);
            this.Controls.Add(this.cbjenisbarang);
            this.Controls.Add(this.lblsampaipenjualan);
            this.Controls.Add(this.dtend);
            this.Controls.Add(this.lbldaripenjualan);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dtstart);
            this.Controls.Add(this.lst);
            this.Controls.Add(this.label1);
            this.Name = "LAPORAN";
            this.Size = new System.Drawing.Size(863, 594);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lst;
        private System.Windows.Forms.DateTimePicker dtstart;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbldaripenjualan;
        private System.Windows.Forms.DateTimePicker dtend;
        private System.Windows.Forms.Label lblsampaipenjualan;
        private System.Windows.Forms.ComboBox cbjenisbarang;
        private System.Windows.Forms.RadioButton rbbarang;
        private System.Windows.Forms.RadioButton rbpenjualan;
        private System.Windows.Forms.ComboBox cbkategori;
        private System.Windows.Forms.Label lblbarang;
        private System.Windows.Forms.Button btncari;
        private System.Windows.Forms.Button btncetak;
    }
}
