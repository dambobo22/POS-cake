﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace POS.CTL
{
    public partial class LOGIN : UserControl
    {
        kp _kp;
        main m;
        public LOGIN(kp _k,main _main)
        {
            InitializeComponent();
            

            _kp = _k;
            pictureBox1.Image = _kp.ImgUsername;
            pictureBox2.Image = _kp.ImgUserpass;
            logo.Image = _kp.ImgMois;
            m = _main;
            txtUserName.GotFocus += txtUserName_GotFocus;
            txtPassword.GotFocus += txtPassword_GotFocus;
            txtUserName.KeyDown += txtUserName_KeyDown;
            txtPassword.KeyDown += txtPassword_KeyDown;

            //_kp.Lap("select '1' as NO,stockName +',' + uomName as BARANG,'3' as QTY,'5000' as HARGA from tStock where stockName = 'CHEESEBURGER'", kp.laporan.receipt, "123456789101", "123");
            //Application.Exit();
        }

        void txtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            //txtUserName.Text = String.Format("{0}", e.KeyValue);
            if (e.KeyValue == 13)
            {
                if (txtUserName.Text == "")
                {
                    m.MessageInfo(main.MessageType.Alert, "USERNAME TIDAK BOLEH KOSONG", 200);
                    txtUserName.Focus();
                }
                else if (txtPassword.Text == "")
                {
                    m.MessageInfo(main.MessageType.Alert, "PASSWORD TIDAK BOLEH KOSONG", 200);
                    txtPassword.Focus();
                }
                else
                {
                    if (m.login(txtUserName.Text.ToUpper(), txtPassword.Text.ToUpper()))
                    {
                        string query = String.Format("update tuser set lastlogindate = GETDATE() where username= '{0}' and password = '{1}'", txtUserName.Text.ToUpper(), txtPassword.Text.ToUpper());
                        if (_kp.CUD(query,txtUserName.Text))
                        {
                            _kp.useractive = txtUserName.Text.ToUpper();
                            m.SetMenu(txtUserName.Text.ToUpper());
                            _kp.log(txtUserName.Text.ToUpper(), "login");
                            m.MessageInfo(main.MessageType.Success, "LOGIN BERHASIL, SELAMAT DATANG, " + m.firstname, 100);
                            txtPassword.Text = "";
                            txtUserName.Text = "";
                            this.Dispose();
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                            txtPassword.Focus();
                        }
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "USERNAME ATAU PASSWORD SALAH", 200);
                        txtPassword.Focus();
                    }
                }
            }
        }

        void txtUserName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue == 13)
            {
                if (txtUserName.Text == "")
                {
                    m.MessageInfo(main.MessageType.Alert, "USERNAME TIDAK BOLEH KOSONG", 200);
                }
                else
                {
                    txtPassword.Focus();
                }
            }
            
        }

        void txtPassword_GotFocus(object sender, EventArgs e)
        {
            m.MessageInfo(main.MessageType.Warning, "SILAHKAN MASUK KAN PASSWORD ANDA", 100);
        }

        void txtUserName_GotFocus(object sender, EventArgs e)
        {
            m.MessageInfo(main.MessageType.Warning, "SILAHKAN MASUK KAN USERNAME ANDA", 100);
        }
    }
}
