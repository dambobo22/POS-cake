﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace POS.CTL
{
    public partial class STOK : UserControl
    {
        kp _kp;
        main m;
        bool isupdate = false;       
        string oldName = "";
        FileInfo _pic;
        public STOK(kp _k,main _main)
        {
            InitializeComponent();            
            _kp = _k;            
            m = _main;
            btnAdd.Image = _kp.ImgAdd;
            btnCancel.Image = _kp.ImgCancel;
            btnSave.Image = _kp.ImgSave;
            btnCancel2.Image = _kp.ImgCancel;
            btnAddStok.Image = _kp.ImgAdd;
            pcGambar.Image = _kp.ImgUsername;
            pcGambar.SizeMode = PictureBoxSizeMode.StretchImage;
            isupdate = true;
            _kp.combo("select tasteName from tTaste where isActive = 1", cbrasa);
            _kp.combo("select categoryName from tCategory where isActive = 1", cbkategori);            
            isupdate = false;
            LoadUser();
            btnAdd.Click += btnAdd_Click;
            btnCancel.Click += btnCancel_Click;
            btnCancel2.Click += btnCancel_Click;
            btnSave.Click += btnSave_Click;
            btnDelete.Click += btnDelete_Click;
            btnAddStok.Click += btnAddModul_Click;           
            lst.DoubleClick += lst_DoubleClick;
            pcGambar.Click += pcGambar_Click;
            txtjumlah.KeyDown += txtjumlah_KeyDown;
            txtharga.KeyPress += _k.DigitOnly;
            txtjumlah.KeyPress += _k.DigitOnly;
            txtstokmasuk.KeyPress += _k.DigitOnly;                    
            cbkategori.SelectedIndexChanged += Cbkategori_SelectedIndexChanged;
          
        }

        void pcGambar_Click(object sender, EventArgs e)
        {
            OpenFileDialog od = new OpenFileDialog();
            od.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp;*.gif";
            od.Title = "Silahkan kan pilih gambar stok.";
            if (od.ShowDialog() == DialogResult.OK)
            {
                FileInfo file = new FileInfo(od.FileName);
                _pic = file;
                txtGambar.Text = file.Name;
                pcGambar.Image = Image.FromFile(file.FullName);               
            }
           
        }
       
        private void Cbkategori_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbkategori.Text != "")
            {
                DataTable uom = _kp.S(string.Format("select B.pmName from tCategory A inner join tPacketMeasurement B ON A.pmId = B.pmId where A.categoryName = '{0}'", cbkategori.Text));
                if (uom.Rows.Count > 0)
                {
                    string _uom = uom.Rows[0].ItemArray[0].ToString();
                    
                    if(_uom == "SATUAN")
                    {                     
                        _kp.combo("select uomName from tUOM where isActive = 1", cbUOM);
                    }
                    else if(_uom == "UKURAN")
                    {
                        _kp.combo("select sizeName from tSize where isActive = 1", cbUOM);
                    }
                   
                }
            }
        }
        void txtjumlah_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyValue != 48)
            {
                txtjumlah.Text = "";
            }
        }
       
        void btnAddModul_Click(object sender, EventArgs e)
        {
            if (!txtnamastok.Enabled)
            {
                if (_kp.ValidateInput(kp.InputType.NumericOnly, txtstokmasuk.Text) != txtstokmasuk.Text)
                {
                    m.MessageInfo(main.MessageType.Alert, "JUMLAH HANYA BOLEH NUMERIC", 100);
                    txtstokmasuk.Focus();
                }
                else
                {
                    string insertquery = "";
                    DataTable stock = _kp.S(String.Format("select stockId from tStock where stockName = '{0}'", txtnamastok.Text));
                    insertquery = String.Format("insert into tStockIn values(NEWID(),'{0}',{1},GETDATE(),NULL)", stock.Rows[0].ItemArray[0].ToString(), txtstokmasuk.Text);
                    string addstok = String.Format("update tStock set qty = qty + {1}, modifiedDate = GETDATE() where stockName = '{0}' ", txtnamastok.Text, txtstokmasuk.Text);
                    addstok += Environment.NewLine + insertquery;
                    if (_kp.CUD(addstok, m.username))
                    {
                        m.MessageInfo(main.MessageType.Success, String.Format("STOK {0} BERHASIL DITAMBAH", txtnamastok.Text), 100);
                        int curStok = Convert.ToInt32(txtjumlah.Text) + Convert.ToInt32(txtstokmasuk.Text);
                        txtjumlah.Text = curStok.ToString();
                        Clear(sender);
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    }
                }
            }
            else
            {
                m.MessageInfo(main.MessageType.Alert, "PILIH MODUL TERLEBIH DULU", 100);
                cbrasa.Focus();
            }
        }
        void btnDelete_Click(object sender, EventArgs e)
        {
            if (btnDelete.Image == _kp.ImgDelete)
            {
                if (txtnamastok.Text == "")
                {
                    m.MessageInfo(main.MessageType.Alert, txtnamastok.Text + " TIDAK BOLEH KOSONG", 100);
                }
                if (txtnamastok.Text == "ADMIN")
                {
                    m.MessageInfo(main.MessageType.Alert, txtnamastok.Text + " TIDAK BOLEH DIHAPUS", 100);
                }
                if (lst.Items.Count == 1)
                {
                    m.MessageInfo(main.MessageType.Alert, "TAMBAH NAMA STOK LAIN TERLEBIH DULU", 100);
                }
                else
                {
                    m.MessageInfo(main.MessageType.Alert, "HANYA BISA DIUBAH JUMLAHNYA SAJA SETELAH DIBUAT UNTUK MENGHINDARI KESALAHAN SISTEM", 200);
                    //string deletequery = "";
                    //deletequery = String.Format("delete from tStock where stockName = '{0}' delete from tStockIn where stockName = '{0}' delete from tStockOut where stockOutId in(select * from tStockOutDetail where stockName = '{0}') delete from tStockOutDetail where stockName = '{0}'", txtnamastok.Text);

                    //if (_kp.CUD(deletequery, m.username))
                    //{
                    //    m.MessageInfo(main.MessageType.Success, String.Format("STOK {0} BERHASIL DIHAPUS", txtnamastok.Text), 100);
                    //    Clear(sender);
                    //}
                    //else
                    //{
                    //    m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    //}

                }
            }
        }
        void lst_DoubleClick(object sender, EventArgs e)
        {
            if(lst.SelectedItems != null)
            {
                isupdate = true;
                txtnamastok.Text = lst.SelectedItems[0].Text;
                cbrasa.Items.Clear();
                cbrasa.Items.Add(lst.SelectedItems[0].SubItems[1].Text);
                cbrasa.SelectedIndex = 0;
                cbkategori.Items.Clear();
                cbkategori.Items.Add(lst.SelectedItems[0].SubItems[2].Text);
                cbkategori.SelectedIndex = 0;
                cbUOM.Items.Clear();
                cbUOM.Items.Add(lst.SelectedItems[0].SubItems[3].Text);
                cbUOM.SelectedIndex = 0;                                         
                txtharga.Text = lst.SelectedItems[0].SubItems[4].Text;
                txtjumlah.Text = lst.SelectedItems[0].SubItems[5].Text;
                txtGambar.Text = lst.SelectedItems[0].SubItems[6].Text;
                control.Location = new Point(0, 120);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2) + 60);
                cbrasa.Enabled = true;
                btnDelete.Image = _kp.ImgDelete;     
                txtnamastok.Enabled = false;
                txtjumlah.Enabled = false;
                 string path = Application.StartupPath + @"\images\" + lst.SelectedItems[0].SubItems[6].Text;
                 if (File.Exists(path))
                 {
                     _pic = new FileInfo(path);
                     pcGambar.ImageLocation = _pic.FullName;
                 }
               
                
            }
        }
        void btnSave_Click(object sender, EventArgs e)
        {
            if(txtnamastok.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "NAMA PENGGUNA TIDAK BOLEH KOSONG", 100);
                txtnamastok.Focus();
            }
            else if (txtharga.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "HARGA TIDAK BOLEH KOSONG", 100);
                txtharga.Focus();
            }
            else if (txtjumlah.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "JUMLAH TIDAK BOLEH KOSONG", 100);
                txtjumlah.Focus();
            }
            else if (cbrasa.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "RASA TIDAK BOLEH KOSONG", 100);
                cbrasa.Focus();
            }
            else if (cbkategori.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "KATEGORI TIDAK BOLEH KOSONG", 100);
                cbkategori.Focus();
            }
            else if (cbUOM.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "UKURAN ATAU SATUAN TIDAK BOLEH KOSONG", 100);
                cbUOM.Focus();
            }            
            else if (_kp.ValidateInput(kp.InputType.NumericOnly, txtharga.Text) != txtharga.Text)
            {
                m.MessageInfo(main.MessageType.Alert, "HARGA HANYA BOLEH NUMERIC", 100);
                txtharga.Focus();
            }
            else if (_kp.ValidateInput(kp.InputType.NumericOnly, txtjumlah.Text) != txtjumlah.Text)
            {
                m.MessageInfo(main.MessageType.Alert, "JUMLAH HANYA BOLEH NUMERIC", 100);
                txtjumlah.Focus();
            }
            else if (txtGambar.Text == "")
            {
                m.MessageInfo(main.MessageType.Alert, "GAMBAR STOK TIDAK BOLEH KOSONG", 100);
                txtGambar.Focus();
            }
            else if (_pic == null)
            {
                m.MessageInfo(main.MessageType.Alert, "GAMBAR STOK TIDAK BOLEH KOSONG", 100);
                txtGambar.Focus();
            }  
            else
            {
                string insertquery = "";
                string updatequery = "";
                DataTable cekdata;
                DataTable Taste = _kp.S(String.Format("select tasteId from tTaste where tasteName = '{0}'", cbrasa.Text));
                DataTable Category = _kp.S(String.Format("select CategoryId from tCategory where categoryName = '{0}'", cbkategori.Text));
                DataTable Uom = _kp.S( String.Format("select uomId from tUOM where uomName = '{0}'", cbUOM.Text));
                DataTable Size = _kp.S(String.Format("select sizeId from tSize where sizeName = '{0}'", cbUOM.Text));
                if (isupdate)
                {
                    updatequery = String.Format("update tStock set tasteId = '{0}',categoryId = '{1}',uomId = {2},sizeId = {3},unitPrice = {4},qty = qty,image = '{6}', modifiedDate = GETDATE() where stockName = '{5}'", Taste.Rows[0].ItemArray[0].ToString(), Category.Rows[0].ItemArray[0].ToString(), Uom.Rows.Count > 0 ? String.Format("'{0}'", Uom.Rows[0].ItemArray[0].ToString()) : "NULL", Size.Rows.Count > 0 ? String.Format("'{0}'", Size.Rows[0].ItemArray[0].ToString()) : "NULL", txtharga.Text, txtnamastok.Text, txtnamastok.Text.Replace(" ", "_") + _pic.Extension);
                    if (_kp.CUD(updatequery, m.username))
                    {
                        try
                        {
                            string path = Application.StartupPath + @"\images\" + txtnamastok.Text.Replace(" ", "_") + _pic.Extension;
                            if (File.Exists(path))
                                File.Delete(path);
                             
                            _pic.CopyTo(path,true);
                        }
                        catch (Exception ex) { m.MessageInfo(main.MessageType.Alert, ex.Message, 200); }
                        m.MessageInfo(main.MessageType.Success, String.Format("STOK {0} BERHASIL DIRUBAH", txtnamastok.Text), 100);
                        Clear(sender);
                    }
                    else
                    {
                        m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                    }
                }
                else
                {
                    insertquery = String.Format("insert into tStock values(NEWID(),'{0}','{1}','{2}',{3},{4},{5},{6},'{7}',GETDATE(),NULL)", txtnamastok.Text, Taste.Rows[0].ItemArray[0].ToString(), Category.Rows[0].ItemArray[0].ToString(), Uom.Rows.Count > 0 ? String.Format("'{0}'", Uom.Rows[0].ItemArray[0].ToString()) : "NULL", Size.Rows.Count > 0 ? String.Format("'{0}'", Size.Rows[0].ItemArray[0].ToString()) : "NULL", txtharga.Text, txtjumlah.Text, txtnamastok.Text.Replace(" ", "_") + _pic.Extension);
                    cekdata = _kp.S(String.Format("select * from tStock where stockName = '{0}'", txtnamastok.Text));
                    if (cekdata.Rows.Count > 0)
                    {
                        m.MessageInfo(main.MessageType.Alert, String.Format("STOK {0} SUDAH ADA", txtnamastok.Text.ToUpper()), 100);
                        txtnamastok.SelectAll();
                    }
                    else
                    {
                        if (_kp.CUD(insertquery, m.username))
                        {

                            try
                            {
                                string path = Application.StartupPath + @"\images\" + txtnamastok.Text.Replace(" ", "_") + _pic.Extension;
                                if (File.Exists(path))
                                    File.Delete(path);
                                _pic.CopyTo(path,true);
                            }
                            catch (Exception ex) { m.MessageInfo(main.MessageType.Alert, ex.Message, 200); }
                            m.MessageInfo(main.MessageType.Success, String.Format("STOK {0} BERHASIL DITAMBAHKAN", txtnamastok.Text.ToUpper()), 100);
                            Clear(sender);
                        }
                        else
                        {
                            m.MessageInfo(main.MessageType.Alert, "TERJADI KESALAHAN SISTEM, HUBUNGI ADMIN ANDA", 200);
                        }
                    }
                }
            }
        }
        void btnCancel_Click(object sender, EventArgs e)
        {
            control.Location = new Point(0, -1200);
            control.Size = new Size(this.Width, control.Height);
            cbrasa.Enabled = true;
            _kp.combo("select tasteName from tTaste where isActive = 1", cbrasa);
            _kp.combo("select categoryName from tCategory where isActive = 1", cbkategori);
            cbrasa.SelectedIndex = -1;
            txtnamastok.Text = "";
            txtGambar.Text = "";
            btnDelete.Image = null;
            isupdate = false;
            txtnamastok.Text = "";
            txtstokmasuk.Text = "";
            txtjumlah.Text = "";
            txtharga.Text = "";
            txtnamastok.Enabled = true;
            txtjumlah.Enabled = true;
            oldName = "";
            pcGambar.Image = _kp.ImgUsername;
            _pic = null;
            LoadUser();
        }
        void Clear(object sender)
        {
            control.Location = new Point(0, -1200);
            control.Size = new Size(this.Width, control.Height);           
            cbrasa.Enabled = true;
            _kp.combo("select tasteName from tTaste where isActive = 1", cbrasa);
            _kp.combo("select categoryName from tCategory where isActive = 1", cbkategori);
            txtnamastok.Text = "";           
            btnDelete.Image = null;
            isupdate = false;
            txtnamastok.Enabled = true;
            txtjumlah.Enabled = true;
            oldName = "";          
            txtnamastok.Text = "";
            txtstokmasuk.Text = "";
            txtjumlah.Text = "";
            txtharga.Text = "";
            txtGambar.Text = "";
            pcGambar.Image = _kp.ImgUsername;
            _pic = null;
            LoadUser();
            
        }
        void btnAdd_Click(object sender, EventArgs e)
        {
                control.Location = new Point(0, 120);
                control.Size = new Size(this.Width, control.Height);
                control.Visible = true;
                control.Location = new Point(0, (this.Height / 2) - (control.Height / 2) + 60);
                cbrasa.Enabled = true;
                txtnamastok.Enabled = true;
                txtnamastok.Focus();   
        } 
        void LoadUser()
        {
            _kp.list("select stockName as NAMA_STOK,tasteName as RASA,categoryName as KATEGORI,ISNULL(D.uomName,E.sizeName) as UOM,unitPrice as HARGA,qty as JUMLAH,image as GAMBAR from tStock A " +
                     "inner join tTaste B ON A.tasteId =  B.tasteId " +
                     "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                     "left join tUOM D ON A.uomId = D.uomId " +
                     "left join tSize E ON A.sizeId = E.sizeId " +
                     "order by A.createdDate,A.modifiedDate desc", lst, 200);
         if (lst.Items.Count == 0) { m.MessageInfo(main.MessageType.Warning, "TABEL KOSONG, SILAHKAN TAMBAH DATA STOK", 100); }
        }

    }
}
