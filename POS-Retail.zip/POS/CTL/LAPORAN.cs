﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace POS.CTL
{
    public partial class LAPORAN : UserControl
    {
        kp _kp;
        main m;
        string query = "";

        public LAPORAN(kp _k, main _main)
        {
            InitializeComponent();            
            _kp = _k;            
            m = _main;
            LoadUser();
            cbjenisbarang.Items.Add("SEMUA");
            cbjenisbarang.Items.Add("KATEGORI");
            rbbarang.CheckedChanged += rbbarang_CheckedChanged;
            rbpenjualan.CheckedChanged += rbpenjualan_CheckedChanged;
            cbjenisbarang.SelectedIndexChanged += cbjenisbarang_SelectedIndexChanged;
            dtstart.ValueChanged += dtstart_ValueChanged;


            btncari.Click += btncari_Click;
            btncetak.Click += btncetak_Click;
        }

        void dtstart_ValueChanged(object sender, EventArgs e)
        {
            if (dtstart.Value != null)
            {
                dtend.MinDate = dtstart.Value;
            }
        }

       
        
        void btncetak_Click(object sender, EventArgs e)
        {
            if (rbbarang.Checked)
            {
                if (cbjenisbarang.SelectedIndex == 0)
                {
                    query = "select ROW_NUMBER() OVER(ORDER BY categoryName ASC) AS NO,categoryName as KATEGORI,tasteName as RASA,ISNULL(D.uomName,E.sizeName) AS SATUAN,qty as STOK,unitPrice as HARGA_STOK from tStock A " +
                           "inner join tTaste B ON A.tasteId =  B.tasteId " +
                           "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                           "left join tUOM D ON A.uomId = D.uomId " +
                           "left join tSize E ON A.sizeId = E.sizeId " +
                           "order by categoryName";
                    _kp.Lap(query, kp.laporan.barang);
                }
                else if (cbjenisbarang.SelectedIndex > 0)
                {
                    query = String.Format("select ROW_NUMBER() OVER(ORDER BY categoryName ASC) AS NO,categoryName as KATEGORI,tasteName as RASA,ISNULL(D.uomName,E.sizeName) AS SATUAN,qty as STOK,unitPrice as HARGA_STOK from tStock A " +
                           "inner join tTaste B ON A.tasteId =  B.tasteId " +
                           "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                           "left join tUOM D ON A.uomId = D.uomId " +
                           "left join tSize E ON A.sizeId = E.sizeId " +
                           "where categoryName = '{0}' " +
                           "order by categoryName", cbkategori.Text);
                    _kp.Lap(query, kp.laporan.barang);
                }
            }

            if (rbpenjualan.Checked)
            {
                if (dtstart.Value <= dtend.Value)
                {
                    query = String.Format("select RIGHT(A.stockOutId,8) as NO_NOTA,CONVERT(VARCHAR(10),A.createdDate,1) as Tanggal,ROW_NUMBER() OVER(ORDER BY A.stockOutId ASC) AS [NO], " +
                                        "C.stockName + ' ' + D.tasteName + ' ' + ISNULL(E.uomName,F.sizeName) as Nama_Barang,C.unitPrice as Harga,B.qty as Qty,(C.unitPrice * B.qty) as TOTAL from tStockOut A " +
                                        "inner join tStockOutDetail B " +
                                        "ON A.stockOutId = B.stockOutId inner join tStock C ON B.stockId = C.stockId " +
                                        "inner join tTaste D ON C.tasteId = D.tasteId " +
                                        "left join tUOM E ON C.uomId = E.uomId " +
                                        "left join tSize F ON C.sizeId = F.sizeId " +
                                        "where A.createdDate >= '{0}' and A.createdDate <='{1}' order by NO_NOTA,Tanggal", dtstart.Value.ToString("yyyy-MM-dd 00:00"), dtend.Value.ToString("yyyy-MM-dd 23:59"));
                    _kp.Lap(query, kp.laporan.penjualan);
                }
                else
                {
                    m.MessageInfo(main.MessageType.Alert, "TANGGAL TIDAK VALID", 100);
                }
            }

          
        }

        void btncari_Click(object sender, EventArgs e)
        {
            if (rbbarang.Checked)
            {
                if (cbjenisbarang.SelectedIndex == 0)
                {
                    query = "select categoryName as KATEGORI,tasteName as RASA,ISNULL(D.uomName,E.sizeName) AS SATUAN,qty as STOK,unitPrice as HARGA_STOK from tStock A " +
                            "inner join tTaste B ON A.tasteId =  B.tasteId " +
                            "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                            "left join tUOM D ON A.uomId = D.uomId " +
                            "left join tSize E ON A.sizeId = E.sizeId " +
                            "order by categoryName";
                }
                else if (cbjenisbarang.SelectedIndex > 0)
                {
                    query = String.Format("select categoryName as KATEGORI,tasteName as RASA,ISNULL(D.uomName,E.sizeName) AS SATUAN,qty as STOK,unitPrice as HARGA_STOK from tStock A " +
                            "inner join tTaste B ON A.tasteId =  B.tasteId " +
                            "inner join tCategory C ON A.CategoryId = C.CategoryId " +
                            "left join tUOM D ON A.uomId = D.uomId " +
                            "left join tSize E ON A.sizeId = E.sizeId " +
                            "where categoryName = '{0}' " +
                            "order by categoryName", cbkategori.Text);
                }
            }

            if (rbpenjualan.Checked)
            {
                if (dtstart.Value <= dtend.Value)
                {
                    query = String.Format("select RIGHT(A.stockOutId,8) as NO_NOTA,CONVERT(VARCHAR(10),A.createdDate,1) as Tanggal,ROW_NUMBER() OVER(ORDER BY A.stockOutId ASC) AS [NO], " +
                                          "C.stockName + ' ' + D.tasteName + ' ' + ISNULL(E.uomName,F.sizeName) as Nama_Barang,C.unitPrice as Harga,B.qty as Qty,(C.unitPrice * B.qty) as TOTAL from tStockOut A " +
                                          "inner join tStockOutDetail B " +
                                          "ON A.stockOutId = B.stockOutId inner join tStock C ON B.stockId = C.stockId " +
                                          "inner join tTaste D ON C.tasteId = D.tasteId " +
                                          "left join tUOM E ON C.uomId = E.uomId " +
                                          "left join tSize F ON C.sizeId = F.sizeId " +
                                          "where A.createdDate >= '{0}' and A.createdDate <='{1}' order by NO_NOTA,Tanggal", dtstart.Value.ToString("yyyy-MM-dd 00:00"), dtend.Value.ToString("yyyy-MM-dd 23:59"));
                }
                else
                {
                    m.MessageInfo(main.MessageType.Alert, "TANGGAL TIDAK VALID", 100);
                }
            }

            if (query != "")
            {
                _kp.list(query, lst, 150);
            }

        }
        void cbjenisbarang_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbjenisbarang.SelectedIndex > 0)
            {
                cbkategori.Visible = true;
                lblbarang.Visible = true;
            }
            else
            {
                cbkategori.Visible = false;
                lblbarang.Visible = false;
            }
        }
        void rbpenjualan_CheckedChanged(object sender, EventArgs e)
        {
                lbldaripenjualan.Visible = rbpenjualan.Checked;
                lblsampaipenjualan.Visible = rbpenjualan.Checked;
                dtstart.Visible = rbpenjualan.Checked;
                dtend.Visible = rbpenjualan.Checked;
           
        }
        void rbbarang_CheckedChanged(object sender, EventArgs e)
        {            
            cbjenisbarang.Visible = rbbarang.Checked;
        }          
        void LoadUser()
        {            
            _kp.combo("select categoryName from tCategory where isActive = 1", cbkategori);
        }
    }
}
