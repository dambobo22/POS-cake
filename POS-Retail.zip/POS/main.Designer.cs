﻿namespace POS
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.viewer = new System.Windows.Forms.Panel();
            this.btnMenu = new System.Windows.Forms.PictureBox();
            this.menuitem = new System.Windows.Forms.Panel();
            this.info = new System.Windows.Forms.Panel();
            this.infotext = new System.Windows.Forms.Label();
            this.infoicon = new System.Windows.Forms.PictureBox();
            this.viewer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).BeginInit();
            this.info.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.infoicon)).BeginInit();
            this.SuspendLayout();
            // 
            // viewer
            // 
            this.viewer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.viewer.BackColor = System.Drawing.Color.White;
            this.viewer.Controls.Add(this.btnMenu);
            this.viewer.Location = new System.Drawing.Point(150, 0);
            this.viewer.Name = "viewer";
            this.viewer.Size = new System.Drawing.Size(640, 480);
            this.viewer.TabIndex = 0;
            // 
            // btnMenu
            // 
            this.btnMenu.BackColor = System.Drawing.Color.White;
            this.btnMenu.Location = new System.Drawing.Point(0, 0);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(52, 50);
            this.btnMenu.TabIndex = 0;
            this.btnMenu.TabStop = false;
            // 
            // menuitem
            // 
            this.menuitem.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.menuitem.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.menuitem.Location = new System.Drawing.Point(0, 0);
            this.menuitem.Name = "menuitem";
            this.menuitem.Size = new System.Drawing.Size(150, 480);
            this.menuitem.TabIndex = 1;
            // 
            // info
            // 
            this.info.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.info.BackColor = System.Drawing.Color.White;
            this.info.Controls.Add(this.infotext);
            this.info.Controls.Add(this.infoicon);
            this.info.Location = new System.Drawing.Point(0, -120);
            this.info.Name = "info";
            this.info.Size = new System.Drawing.Size(640, 120);
            this.info.TabIndex = 2;
            // 
            // infotext
            // 
            this.infotext.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.infotext.ForeColor = System.Drawing.SystemColors.ControlText;
            this.infotext.Location = new System.Drawing.Point(124, 0);
            this.infotext.Name = "infotext";
            this.infotext.Size = new System.Drawing.Size(513, 120);
            this.infotext.TabIndex = 1;
            this.infotext.Text = "_";
            this.infotext.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // infoicon
            // 
            this.infoicon.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.infoicon.BackColor = System.Drawing.Color.White;
            this.infoicon.Location = new System.Drawing.Point(0, 0);
            this.infoicon.Name = "infoicon";
            this.infoicon.Size = new System.Drawing.Size(125, 120);
            this.infoicon.TabIndex = 0;
            this.infoicon.TabStop = false;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(640, 480);
            this.Controls.Add(this.info);
            this.Controls.Add(this.viewer);
            this.Controls.Add(this.menuitem);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "main";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.viewer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).EndInit();
            this.info.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.infoicon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel viewer;
        private System.Windows.Forms.PictureBox btnMenu;
        private System.Windows.Forms.Panel menuitem;
        private System.Windows.Forms.Panel info;
        private System.Windows.Forms.PictureBox infoicon;
        private System.Windows.Forms.Label infotext;
    }
}

