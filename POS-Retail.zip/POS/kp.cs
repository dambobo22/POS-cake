﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.IO;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using POS.Properties;
namespace POS
{
    public class kp
    {
        #region variable
        private SqlConnection con;
        private SqlCommand cmd;
        private SqlDataReader read;
        private SqlTransaction trans;
        public System.Drawing.Image ImgOpen = Resources.open;
        public System.Drawing.Image ImgClose = Resources.close;
        public System.Drawing.Image ImgLogo = Resources.logo;
        public System.Drawing.Image ImgAdd = Resources.add;
        public System.Drawing.Image ImgDelete = Resources.delete;
        public System.Drawing.Image ImgSave = Resources.save;
        public System.Drawing.Image ImgCancel = Resources.cancel;
        public System.Drawing.Image ImgKasir = Resources.kasir;
        public System.Drawing.Image ImgMaster = Resources.master;
        public System.Drawing.Image ImgPengguna = Resources.pengguna;
        public System.Drawing.Image ImgStok = Resources.stok;
        public System.Drawing.Image ImgHelp = Resources.help;
        public System.Drawing.Image ImgLogout = Resources.logout;
        public System.Drawing.Image ImgPassword = Resources.password;
        public System.Drawing.Image ImgKeluar = Resources.keluar;
        public System.Drawing.Image ImgWarn = Resources.warn;
        public System.Drawing.Image ImgAlert = Resources.alert;
        public System.Drawing.Image ImgSuccess = Resources.success;
        public System.Drawing.Image ImgUsername = Resources.username;
        public System.Drawing.Image ImgUserpass = Resources.userpass;
        public System.Drawing.Image ImgActive = Resources.active;
        public System.Drawing.Image ImgHover = Resources.hover;
        public System.Drawing.Image ImgClicked = Resources.clicked;
        public System.Drawing.Image ImgLaporan = Resources.laporan;
        public System.Drawing.Image ImgMois = Resources.moislogo;
        public System.Drawing.Image ImgPay = Resources.pay;
        public string useractive { get; set; }
        //BaseFont f_cb = BaseFont.CreateFont("c:\\windows\\fonts\\calibrib.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
        //BaseFont f_cn = BaseFont.CreateFont("c:\\windows\\fonts\\calibri.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED);
        BaseFont f_cb = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1257, BaseFont.EMBEDDED);
        BaseFont f_cn = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1257, BaseFont.EMBEDDED);
        #endregion variable
        #region initial
        public kp()
        {
            string hostdb = "127.0.0.1";
            con = new SqlConnection("Data source=TOSHIBA\\SQLEXPRESS;Initial Catalog=KP;Integrated Security=True;");
        }
        #endregion initial
        #region function
        public void SetAutoComplete(TextBox ctl, string query)
        {
            AutoCompleteStringCollection auto = new AutoCompleteStringCollection();
            DataTable _auto = S(query);
            List<String> autolist = new List<String>();
            foreach (DataRow r in _auto.Rows)
            {
                autolist.Add(r.ItemArray[0].ToString());
            }
            foreach (String r in autolist)
            {
                if (!auto.Contains(r))
                {
                    auto.Add(r);
                }
            }
            ctl.AutoCompleteSource = AutoCompleteSource.CustomSource;
            ctl.AutoCompleteCustomSource = auto;
            ctl.AutoCompleteMode = AutoCompleteMode.SuggestAppend;

        }
        public DataTable S(string query)
        {
            DataTable temp = new DataTable();
            try
            {
                if (con.State != ConnectionState.Open) { con.Open(); }
                cmd = new SqlCommand(query, con);
                read = cmd.ExecuteReader();
                temp.Load(read);
            }
            catch { }
            return temp;
        }
        public bool CUD(string query, string username)
        {
            bool temp = false;
            try
            {
                if (con.State != ConnectionState.Open) { con.Open(); }
                try
                {
                    cmd = new SqlCommand();
                    cmd.Connection = con;
                    cmd.CommandText = query;
                    cmd.CommandType = CommandType.Text;
                    trans = con.BeginTransaction();
                    cmd.Transaction = trans;
                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        trans.Commit();
                        temp = true;
                    }
                }
                catch (Exception ex) { trans.Rollback(); error(username, ex.Message.Replace("'", "|"), query.Replace("'", "|")); }

            }
            catch { }
            return temp;
        }
        public void log(string username, string remark)
        {
            CUD(string.Format("insert into tLog values(NEWID(),'{0}','{1}',GETDATE())", username, remark), username);
        }
        public void error(string username, string message, string errquery)
        {
            CUD(string.Format("insert into tErrorException values(NEWID(),'{0}','{1}','{2}',GETDATE())", username, message, errquery), username);
        }
        public string NEWID()
        {
            string temp = "";
            DataTable id = S("select NEWID()");
            if (id.Rows.Count > 0)
            {
                temp = id.Rows[0].ItemArray[0].ToString();
            }
            return temp;
        }
        public void list(string query, ListView lst, int clwidth)
        {
            DataTable data = S(query);
            lst.Clear();
            if (data.Rows.Count > 0)
            {
                foreach (DataColumn c in data.Columns)
                {
                    lst.Columns.Add(c.ColumnName, clwidth);
                }
                foreach (DataRow r in data.Rows)
                {
                    string[] str = new string[r.ItemArray.Length];
                    for (int i = 0; i < r.ItemArray.Length; i++)
                    {
                        str[i] = r.ItemArray[i].ToString();
                    }
                    lst.Items.Add(new ListViewItem(str));
                }
            }
            else
            {
                lst.Clear();
            }
        }
        public void listImage(string query, ListView lst, int clwidth)
        {
            DataTable data = S(query);
            lst.Clear();
            ImageList largeicon = new ImageList();
            largeicon.ImageSize = new Size(48, 48);            
            lst.LargeImageList = largeicon;
            lst.SmallImageList = largeicon;
            lst.StateImageList = largeicon;
            if (data.Rows.Count > 0)
            {
                foreach (DataColumn c in data.Columns)
                {
                    lst.Columns.Add(c.ColumnName, clwidth);
                }
                foreach (DataRow r in data.Rows)
                {
                    object[] o = r.ItemArray;
                    System.Drawing.Image img = System.Drawing.Image.FromFile(Application.StartupPath + @"/images/" + o[1].ToString());
                        largeicon.Images.Add(o[1].ToString(),img);
                    string[] str = new string[r.ItemArray.Length];
                    for (int i = 0; i < r.ItemArray.Length; i++)
                    {
                        str[i] = r.ItemArray[i].ToString();
                    }
                    lst.Items.Add(new ListViewItem(str, o[1].ToString()));
                }
            }
            else
            {
                lst.Clear();
            }
        }
        public void combo(string query, ComboBox sb)
        {
            DataTable data = S(query);
            sb.Items.Clear();
            if (data.Rows.Count > 0)
            {
                foreach (DataRow r in data.Rows)
                {
                    sb.Items.Add(r.ItemArray[0].ToString().ToUpper());
                }
            }
        }
        public enum InputType
        {
            NumericOnly, AlphabetOnly, General, Email
        }
        public string ValidateInput(InputType input, string inputstr)
        {
            string temp = "";
            string regex = "";
            switch (input)
            {
                case InputType.NumericOnly: regex = @"^\d+$"; break;
                case InputType.Email: regex = @"^[\w-]+@([\w-]+\.)+[\w-]+$"; break;
            }
            if (regex != "")
            {
                Regex r = new Regex(regex);
                if (r.IsMatch(inputstr))
                {
                    temp = inputstr;
                }
            }
            return temp;
        }

        private void writebarcode(PdfContentByte con, string code, string alt, int x, int y, int width, int height, int align)
        {
            Barcode128 bc = new Barcode128();
            bc.TextAlignment = align;
            bc.AltText = alt;
            bc.Code = code;
            bc.StartStopText = false;
            bc.CodeType = Barcode128.EAN13;
            bc.Extended = true;
            iTextSharp.text.Image img = bc.CreateImageWithBarcode(con, BaseColor.BLACK, BaseColor.BLACK);
            img.SetAbsolutePosition(x, y);
            img.ScaleAbsolute(width, height);
            con.AddImage(img);
        }
        private void writeConfirmationCode(PdfContentByte con, string code, int x, int y, int width, int height)
        {
            BarcodeQRCode bc = new BarcodeQRCode(code, 1, 1, null);
            iTextSharp.text.Image img = bc.GetImage();
            img.SetAbsolutePosition(x, y);
            img.ScaleAbsolute(width, height);
            con.AddImage(img);
        }
        public enum laporan
        {
            barang, penjualan, receipt
        }
        public bool Lap(string query, laporan jenis, params string[] param)
        {
            bool temp = false;
            string filename = jenis.ToString() + DateTime.Now.ToString("yyyyMMddHHmmss");
            string file = Application.StartupPath + String.Format(@"\\report\\{0}.pdf", filename);
            if (File.Exists(file)) { File.Delete(file); }
            try
            {
                using (System.IO.FileStream fs = new FileStream(file, FileMode.Create))
                {
                    Document document = new Document(PageSize.A4, 25, 25, 30, 30);
                    PdfWriter writer = PdfWriter.GetInstance(document, fs);
                    int page = 1;
                    document.AddAuthor("IRWIN");
                    document.AddCreator("IRWIN");
                    document.AddKeywords("PDF LAPORAN STRUK");
                    if (jenis == laporan.barang)
                    {
                        document.AddSubject("LAPORAN BARANG");
                        document.AddTitle("LAPORAN BARANG");
                    }
                    else if (jenis == laporan.penjualan)
                    {
                        document.AddSubject("LAPORAN PENJUALAN");
                        document.AddTitle("LAPORAN PENJUALAN");
                    }
                    else if (jenis == laporan.receipt)
                    {
                        document.AddSubject("STRUK PEMBELIAN");
                        document.AddTitle("STRUK PEMBELIAN");
                    }
                    document.Open();
                    PdfContentByte cb = writer.DirectContent;
                    cb.SetLineWidth(1f);
                    cb.MoveTo(25, 720);
                    cb.LineTo(575, 720);
                    cb.Stroke();
                    cb.SetLineWidth(1f);
                    cb.MoveTo(25, 28);
                    cb.LineTo(575, 28);
                    cb.Stroke();
                    cb.BeginText();
                    cb.SetTextMatrix(0, 810); // Left, Top
                    //HEADER//
                    iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(ImgMois, iTextSharp.text.BaseColor.BLACK);
                    jpg.ScaleToFit(140f, 130f);
                    jpg.SpacingBefore = 10f;
                    jpg.SpacingAfter = 1f;
                    if (jenis != laporan.receipt)
                    {
                        jpg.Alignment = Element.ALIGN_LEFT;
                            document.Add(jpg);
                        cb.SetFontAndSize(f_cb, 28);
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "MOIS LAYER CAKE", 170, 795, 0);
                        cb.SetFontAndSize(f_cb, 14);
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "SOUTH WALK - 6 C, Nagoya CityWalk,", 170, 772, 0);
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Jl. Imam Bonjol, Lubuk Baja, Kota Batam,", 170, 752, 0);
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "Kepulauan Riau", 170, 732, 0);
                        //HEADER
                        //BODY//
                    }
                    else
                    {
                        jpg.Alignment = Element.ALIGN_CENTER;
                        document.Add(jpg);
                        cb.SetFontAndSize(f_cb, 24);
                    }
                    if (jenis == laporan.barang)
                    {
                        cb.SetFontAndSize(f_cb, 18);
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "LAPORAN BARANG", 30, 700, 0);
                    }
                    else if (jenis == laporan.penjualan)
                    {
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "LAPORAN PENJUALAN", 30, 700, 0);
                    }
                    else if (jenis == laporan.receipt)
                    {
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, String.Format("ID: {0} PRINTED: {1}", param[0].ToUpper(), DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")), 30, 700, 0);
                    }
                    cb.EndText();
                    DataTable data = S(query);
                    if (data.Rows.Count > 0)
                    {
                        if (jenis == laporan.barang)
                        {
                            #region barang
                            int X = 25;
                            int Y = 680;
                            int Z = 100;
                            for (int c = 0; c < data.Columns.Count; c++)
                            {
                                if (c == 0)
                                {
                                    cb.SetLineWidth(1f);
                                    cb.MoveTo(X, Y);
                                    cb.LineTo(X + 20, Y);
                                    cb.Stroke();
                                    X += 20 + 5;
                                }
                                else
                                {
                                    cb.SetLineWidth(1f);
                                    cb.MoveTo(X, Y);
                                    cb.LineTo(X + Z, Y);
                                    cb.Stroke();
                                    X += Z + 5;
                                }
                            }
                            X = 25;
                            Y = 680;
                            Z = 100;
                            cb.BeginText();
                            for (int c = 0; c < data.Columns.Count; c++)
                            {
                                if (c == 0)
                                {
                                    cb.SetFontAndSize(f_cb, 10);
                                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Columns[c].ColumnName, X, Y + 5, 0);
                                    Y = Y - 12;
                                    for (int r = 0; r < data.Rows.Count; r++)
                                    {
                                        cb.SetFontAndSize(f_cb, 8);
                                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Rows[r].ItemArray[c].ToString(), X, Y + 5, 0);
                                        Y = Y - 8;
                                        if (Y <= 20)
                                        {
                                            AddPage(document, cb);
                                        }
                                    }
                                    X += 20 + 5;
                                }
                                else
                                {
                                    cb.SetFontAndSize(f_cb, 10);
                                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Columns[c].ColumnName, X, Y + 5, 0);
                                    Y = Y - 12;
                                    for (int r = 0; r < data.Rows.Count; r++)
                                    {
                                        cb.SetFontAndSize(f_cb, 8);
                                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Rows[r].ItemArray[c].ToString(), X, Y + 5, 0);
                                        Y = Y - 8;
                                        if (Y <= 20)
                                        {
                                            AddPage(document, cb);
                                        }
                                    }
                                    X += Z + 5;
                                }
                                Y = 680;

                            }
                            cb.EndText();
                            #endregion barang
                        }
                        else if (jenis == laporan.penjualan)
                        {
                            #region penjualan
                            int X = 25;
                            int Y = 680;
                            int Z = 150;
                            cb.BeginText();
                            string col = "";
                            int row = 0;
                            for (int r = 0; r < data.Rows.Count; r++)
                            {
                                object[] o = data.Rows[r].ItemArray;

                                for (int c = 0; c < data.Columns.Count; c++)
                                {
                                    if (c == 1)
                                    {
                                        if (col != String.Format("NO.NOTA: {0} TANGGAL: {1}", o[0], o[1]))
                                        {
                                            if (r > 0)
                                            {
                                                cb.EndText();
                                                cb.SetLineWidth(1f);
                                                cb.MoveTo(25, Y);
                                                cb.LineTo(575, Y);
                                                cb.Stroke();
                                                cb.BeginText();
                                            }
                                            row = 1;
                                            Y = Y - 15;
                                            col = String.Format("NO.NOTA: {0} TANGGAL: {1}", o[0], o[1]);
                                            cb.SetFontAndSize(f_cb, 8);
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, col, X, Y + 5, 0);
                                            Y = Y - 15;
                                            X = 25;
                                        }
                                    }
                                    else if (c > 1)
                                    {
                                        if (c == 2)
                                        {
                                            cb.SetFontAndSize(f_cb, 8);
                                            if (row == 1)
                                            {
                                                cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Columns[c].ColumnName, X, Y + 8, 0);
                                            }
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, row.ToString(), X, Y, 0);
                                            row++;
                                            X += 20 + 5;
                                        }
                                        else
                                        {
                                            cb.SetFontAndSize(f_cb, 8);
                                            if (row == 2)
                                            {
                                                cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Columns[c].ColumnName, X, Y + 8, 0);
                                            }
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, o[c].ToString(), X, Y, 0);
                                            X += Z + 5;
                                        }
                                    }
                                }
                                Y = Y - 8;
                                X = 25;
                            }

                            cb.EndText();
                            #endregion penjualan
                        }
                        else if (jenis == laporan.receipt)
                        {
                            int X = 25;
                            int Y = 650;
                            int Z = 165;
                            for (int c = 0; c < data.Columns.Count; c++)
                            {
                                if (c == 0)
                                {
                                    cb.SetLineWidth(1f);
                                    cb.MoveTo(X, Y);
                                    cb.LineTo(X + 40, Y);
                                    cb.Stroke();
                                    X += 40 + 5;
                                }
                                else
                                {
                                    cb.SetLineWidth(1f);
                                    cb.MoveTo(X, Y);
                                    if (c == 1)
                                    {
                                        cb.LineTo(X + 300, Y);
                                        cb.Stroke();
                                        X += 300 + 5;
                                    }
                                    else if (c == 2)
                                    {
                                        cb.LineTo(X + 70, Y);
                                        cb.Stroke();
                                        X += 70 + 5;
                                    }
                                    else if (c == 3)
                                    {
                                        cb.LineTo(X + 135, Y);
                                        cb.Stroke();
                                        X += 135 + 5;
                                    }
                                    else
                                    {
                                        cb.LineTo(X + Z, Y);
                                        cb.Stroke();
                                        X += Z + 5;
                                    }
                                }
                            }
                            X = 25;
                            Y = 650;
                            Z = 165;
                            cb.BeginText();
                            for (int c = 0; c < data.Columns.Count; c++)
                            {
                                if (c == 0)
                                {
                                    cb.SetFontAndSize(f_cb, 24);
                                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Columns[c].ColumnName, X, Y + 5, 0);
                                    Y = Y - 30;
                                    for (int r = 0; r < data.Rows.Count; r++)
                                    {
                                        cb.SetFontAndSize(f_cb, 24);
                                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Rows[r].ItemArray[c].ToString(), X, Y + 5, 0);
                                        Y = Y - 30;
                                        if (Y <= 20)
                                        {
                                            AddPage(document, cb);
                                        }
                                    }
                                    X += 40 + 5;
                                }
                                else
                                {
                                    cb.SetFontAndSize(f_cb, 24);
                                    cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Columns[c].ColumnName, X, Y + 5, 0);
                                    Y = Y - 30;
                                    for (int r = 0; r <= data.Rows.Count; r++)
                                    {
                                        cb.SetFontAndSize(f_cb, 24);
                                        if (r < data.Rows.Count)
                                        {

                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, data.Rows[r].ItemArray[c].ToString(), X, Y + 5, 0);
                                        }                                      
                                        else if(c == (data.Columns.Count - 3))
                                        {
                                            cb.SetFontAndSize(f_cb, 24);
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "DIBAYAR", X, Y, 0);
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "TOTAL", X, Y-20, 0);
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, "KEMBALIAN", X, Y - 40, 0);
                                            
                                        }
                                        else if (c == (data.Columns.Count - 1))
                                        {
                                            cb.SetFontAndSize(f_cb, 24);
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, param[1], X, Y, 0);
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, param[2], X, Y-20, 0);
                                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, param[3], X, Y - 40, 0);
                                        }
                                        Y = Y - 30;
                                        if (Y <= 20)
                                        {
                                            AddPage(document, cb);
                                        }
                                    }
                                    if (c == 1)
                                    {
                                        X += 300 + 5;
                                    }
                                    else if (c == 2)
                                    {
                                        X += 70 + 5;
                                    }
                                    else if (c == 3)
                                    {
                                        X += 135 + 5;
                                    }
                                    else
                                    {
                                        X += Z + 5;
                                    }

                                }
                                Y = 650;

                            }
                            cb.EndText();
                        }
                    }
                    document.Close();
                    writer.Close();
                    fs.Close();
                    temp = true;
                    System.Diagnostics.Process.Start(file);
                }
            }
            catch (Exception e)
            {

            }
            return temp;

        }
        void AddPage(Document doc, PdfContentByte _cb)
        {
            _cb.EndText();
            doc.NewPage();
            _cb.BeginText();
            _cb.SetTextMatrix(0, 810); // Left, Top
        }
        public void DigitOnly(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }
        public void DecimalOnly(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && e.KeyChar != '.';
        }
        #endregion function
    }
}
