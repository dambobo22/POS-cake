﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using POS.CTL;

namespace POS
{
    public partial class main : Form
    {
        public bool isopen = true;
        public bool dropInOut = false;
        public int _X = 0;
        public int _Y = -120;
        public int _WAIT = 100;
        public Timer slider = new Timer();
        public Timer dropdown = new Timer();
        kp k = new kp();
        
        public Font defStyle = new Font("Segoe UI Bold", 10.0f); //ARIAL for default
        public Font defStyle2 = new Font("Segoe UI Bold", 28.0f); //ARIAL for default
        public string username = "";
        public string firstname = "";
        public main()
        {
            InitializeComponent();  
            btnMenu.Image = k.ImgOpen;
            //string query = String.Format("select RIGHT(A.stockOutId,8) as NO_NOTA,CONVERT(VARCHAR(10),A.createdDate,1) as Tanggal,ROW_NUMBER() OVER(ORDER BY A.stockOutId ASC) AS [NO],C.stockName + ' ' + C.tasteName + ' ' + ISNULL(C.sizeName,C.uomName) as Nama_Barang,C.unitPrice as Harga,B.qty as Qty,(C.unitPrice * B.qty) as TOTAL from tStockOut A " +
            //                             "inner join tStockOutDetail B ON A.stockOutId = B.stockOutId " +
            //                             "inner join tStock C ON B.stockName = C.stockName " +
            //                             "where A.createdDate >= '{0}' and A.createdDate <='{1}' " +
            //                             "order by NO_NOTA,Tanggal", "2016-01-01 00:00", "2016-04-12 23:59");
            //k.Lap(query, kp.laporan.penjualan);
            Application.Exit();
            this.Resize += main_Resize;
            btnMenu.Click += btnMenu_Click;
            slider.Interval = 1;
            slider.Tick += slider_Tick;
            dropdown.Interval = 1;
            dropdown.Tick += dropdown_Tick;
            slider.Start();           
            LOGIN login = new LOGIN(k,this);
            login.Name = "ACTIVE";
            login.Dock = DockStyle.Fill;
            viewer.Controls.Add(login);
            clearMenu();
        }
        public bool login(string _username, string password)
        {
            bool temp = false;
            DataTable user = k.S(String.Format("select FirstName from tUser where userName = '{0}' and passWord = '{1}'", _username, password));
            if (user.Rows.Count > 0)
            {
                firstname = user.Rows[0].ItemArray[0].ToString();
                temp = true;
            }
            return temp;
        }
        public void SetMenu(string _username)
        {
            username = _username;
            foreach (Control c in menuitem.Controls)
            {
                c.Dispose();
            }
            DataTable _menu = k.S(String.Format("select C.roleName from tUser A inner join tUserRole B ON A.userName = B.userName inner join tRole C ON B.roleId = C.roleId where C.isActive = 1 and  A.userName = '{0}' order by C.roleName",username));
            int _X = 0;
            int _Y = 70;
            foreach (DataRow r in _menu.Rows)
            {
                object[] o = r.ItemArray;                
                AddMenu(menuitem, o[0].ToString(), _X, _Y);
                _X += _Y;
            }
            AddMenu(menuitem, "PENGGUNA DETAIL", _X, _Y);
            _X += _Y;
            AddMenu(menuitem, "LOGOUT", _X, _Y);
            _X += _Y;
            AddMenu(menuitem, "KELUAR", _X, _Y);
            _X += _Y;
            slider.Start();
        }
        void clearMenu()
        {
            username = "";
            firstname = "";
            menuitem.Controls.Clear();
            int _X = 0;
            int _Y = 70;           
            AddMenu(menuitem, "KELUAR", _X, _Y);
            slider.Start();
        }
        void AddMenu(Control _parent,string _name,int _X, int _Y)
        {
            Button pic = new Button();
            pic.Name = _name;
            pic.Text = _name;
            pic.Click += pic_Click;
            pic.Size = new Size(150, _Y);
            pic.Location = new Point(0, _X);
            pic.FlatStyle = FlatStyle.Flat;
            pic.FlatAppearance.BorderSize = 0;
            pic.Font = defStyle;
            pic.ForeColor = Color.White;
            pic.ImageAlign = ContentAlignment.MiddleLeft;
            switch (_name)
            {
                case "KASIR": pic.Image = k.ImgKasir; break;
                case "MASTER": pic.Image = k.ImgMaster; break;
                case "PENGGUNA": pic.Image = k.ImgPengguna; break;
                case "STOK": pic.Image = k.ImgStok; break;
                case "LAPORAN": pic.Image = k.ImgLaporan; break;
                case "PENGGUNA DETAIL": pic.Image = k.ImgPassword; break;
                case "LOGOUT": pic.Image = k.ImgLogout; break;
                case "KELUAR": pic.Image = k.ImgKeluar; break;
            }
            pic.TextImageRelation = TextImageRelation.ImageBeforeText;
            _parent.Controls.Add(pic);
        }
        void pic_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;           
            foreach (Control c in viewer.Controls)
            {
                if (c.Name == "ACTIVE") { c.Dispose(); }
            }
            switch (btn.Name)
            {
                case "KASIR": 
                    KASIR kasir = new KASIR(k, this);
                    kasir.Name = "ACTIVE";
                    kasir.Dock = DockStyle.Fill;
                    viewer.Controls.Add(kasir);
                    k.log(username, "open kasir");
                    slider.Start();
                    break;
                case "MASTER":
                    MASTER master = new MASTER(k, this);
                    master.Name = "ACTIVE";
                    master.Dock = DockStyle.Fill;
                    viewer.Controls.Add(master);
                    k.log(username, "open master");
                    slider.Start();                
                    break;
                case "PENGGUNA": 
                    PENGGUNA pengguna = new PENGGUNA(k, this);
                    pengguna.Name = "ACTIVE";
                    pengguna.Dock = DockStyle.Fill;
                    viewer.Controls.Add(pengguna);
                    k.log(username, "open pengguna");
                    slider.Start();
                    break;
                case "STOK":
                    STOK stok = new STOK(k, this);
                    stok.Name = "ACTIVE";
                    stok.Dock = DockStyle.Fill;
                    viewer.Controls.Add(stok);
                    k.log(username, "open stok");
                    slider.Start();                
                    break;
                case "LAPORAN":
                    LAPORAN laporan = new LAPORAN(k, this);
                    laporan.Name = "ACTIVE";
                    laporan.Dock = DockStyle.Fill;
                    viewer.Controls.Add(laporan);
                    k.log(username, "open laporan");
                    slider.Start();
                    break;
                case "PENGGUNA DETAIL":
                    PASSWORD password = new PASSWORD(k, this);
                    password.Name = "ACTIVE";
                    password.Dock = DockStyle.Fill;
                    viewer.Controls.Add(password);
                    k.log(username, "open pengguna detail");
                    slider.Start();
                    break;                 
                case "LOGOUT":
                    LOGIN login = new LOGIN(k,this);
                    login.Name = "ACTIVE";
                    login.Dock = DockStyle.Fill;
                    viewer.Controls.Add(login);
                    MessageInfo(main.MessageType.Success, "SAMPAI JUMPA LAGI, " + firstname, 100);
                    k.log(username, "logout");
                    clearMenu();                    
                    break;
                case "KELUAR":
                    Application.Exit();
                    break;
            }
        }
        public void dropdown_Tick(object sender, EventArgs e)
        {
                if (_Y < 0 && !dropInOut)
                {
                    _Y += 10;
                    info.Location = new Point(0, _Y);
                } 
                else if (!dropInOut)
                {
                    _WAIT--;
                    if (_WAIT <= 0) { dropInOut = true; }
                }
                else
                {                    
                    info.Location = new Point(0, _Y);
                    _Y -= 10;                    
                    if (_Y < -120)
                    {
                        dropdown.Stop();
                        dropInOut = false;
                    }
                }
        }
        public void slider_Tick(object sender, EventArgs e)
        {
            if (isopen)
            {
                if (viewer.Location.X > 0)               
                {
                    viewer.Location = new Point(_X,0);
                    _X -= 10;
                }
                else
                {
                    isopen = false;                    
                    slider.Stop();
                    btnMenu.Image = k.ImgClose;
                }
            }
            else
            {
                if (viewer.Location.X < 150)
                {
                    viewer.Location = new Point(_X, 0);
                    _X += 10;
                }
                else
                {
                    isopen = true;
                    slider.Stop();
                    btnMenu.Image = k.ImgOpen;
                }
            }
        }
        void btnMenu_Click(object sender, EventArgs e)
        {
            _X = viewer.Location.X;
            _Y = info.Location.Y;           
            if (isopen)
            {
                slider.Start();               
            }
            else
            {              
                slider.Start();              
            }
            
        }
        public void MessageInfo(MessageType type,string message,int timeout)
        {
            infoicon.SizeMode = PictureBoxSizeMode.CenterImage;
            infotext.Text = message;
            infotext.Font = defStyle2;
            infotext.ForeColor = Color.White;
            switch (type)
            {
                case MessageType.Success:
                    infoicon.Image = k.ImgSuccess;
                    infoicon.BackColor = Color.Turquoise;
                    info.BackColor = Color.Turquoise;
                    break;
                case MessageType.Warning:
                    infoicon.Image = k.ImgWarn;
                    infoicon.BackColor = Color.Orange;
                    info.BackColor = Color.Orange;
                    break;
                case MessageType.Alert:
                    infoicon.Image = k.ImgAlert;
                    infoicon.BackColor = Color.Salmon;
                    info.BackColor = Color.Salmon;
                    break;
            }
            _WAIT = timeout;
            dropdown.Start();
        }
        public enum MessageType
        {
            Warning,Success,Alert
        }
        void main_Resize(object sender, EventArgs e)
        {
            viewer.Size = new Size(this.Width, this.Height);
            info.Size = new Size(this.Width, 120);
            info.Location = new Point(0, -120);
            if (isopen)
            {
                viewer.Location = new Point(150, 0);
               
            }
            else
            {
                viewer.Location = new Point(0, 0);
            }
            _X = viewer.Location.X;
        }
    }
}
